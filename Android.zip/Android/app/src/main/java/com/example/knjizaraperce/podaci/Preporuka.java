package com.example.knjizaraperce.podaci;

import java.util.LinkedList;
import java.util.List;

public class Preporuka {
    private String od;
    private String za;
    private int knjiga;
    private int prikaz;

    private static List<Preporuka> preporuke = new LinkedList<>();

    public Preporuka(String od, String za, int knjiga, int prikaz) {
        this.od = od;
        this.za = za;
        this.knjiga = knjiga;
        this.prikaz = prikaz;
    }

    public String getOd() {
        return od;
    }

    public void setOd(String od) {
        this.od = od;
    }

    public String getZa() {
        return za;
    }

    public void setZa(String za) {
        this.za = za;
    }

    public int getKnjiga() {
        return knjiga;
    }

    public void setKnjiga(int knjiga) {
        this.knjiga = knjiga;
    }

    public int getPrikaz() {
        return prikaz;
    }

    public void setPrikaz(int prikaz) {
        this.prikaz = prikaz;
    }

    public static List<Preporuka> getPreporuke() {
        return preporuke;
    }

    public void insert(Preporuka p){
        preporuke.add(p);
    }

    public static void init(){
        if(!preporuke.isEmpty()) return;
        preporuke.add(new Preporuka(
                "zika",
                "pera",
                0,
                1
        ));
        preporuke.add(new Preporuka(
                "zika",
                "pera",
                4,
                1
        ));
        preporuke.add(new Preporuka(
                "mika",
                "pera",
                4,
                1
        ));
        preporuke.add(new Preporuka(
                "vesna",
                "pera",
                1,
                1
        ));
        preporuke.add(new Preporuka(
                "vesna",
                "pera",
                3,
                1
        ));
    }
}

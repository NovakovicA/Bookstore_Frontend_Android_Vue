package com.example.knjizaraperce.podaci;

import java.util.LinkedList;
import java.util.List;

public class Korisnik {
    private String ime;
    private String prezime;
    private String korime;
    private String lozinka;
    private String brojTelefona;
    private String adresa;
    private int tip;

    private static Korisnik ulogovaniKorisnik=null;

    private static List<Korisnik> korisnici = new LinkedList<>();


    public Korisnik(String ime, String prezime, String korime, String lozinka, String brojTelefona, String adresa, int tip) {
        this.ime = ime;
        this.prezime = prezime;
        this.korime = korime;
        this.lozinka = lozinka;
        this.brojTelefona = brojTelefona;
        this.adresa = adresa;
        this.tip = tip;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getKorime() {
        return korime;
    }

    public void setKorime(String korime) {
        this.korime = korime;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public String getBrojTelefona() {
        return brojTelefona;
    }

    public void setBrojTelefona(String brojTelefona) {
        this.brojTelefona = brojTelefona;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public int getTip() {
        return tip;
    }

    public void setTip(int tip) {
        this.tip = tip;
    }

    public static void insert(Korisnik k){
        korisnici.add(k);
    }

    public static List<Korisnik> getKorisnici(){
        return korisnici;
    }

    public static boolean login(String username, String password){
        for(Korisnik i:korisnici){
                if(i.getKorime().equals(username) && i.getLozinka().equals(password)
                && i.getTip()==0){
                    ulogovaniKorisnik=i;
                    return true;
                }
        }
        return false;
    }

    public static Korisnik getUlogovaniKorisnik() {
        return ulogovaniKorisnik;
    }

    public static void logoff(){
        ulogovaniKorisnik=null;
    }

    public static void init(){
        if(!korisnici.isEmpty()) return;
        korisnici.add(new Korisnik("Pera",
                "Perić",
                "pera",
                "123",
                "0614325222",
                "Ustanička 11, Beograd",
                0));
        korisnici.add(new Korisnik( "Žika",
                "Žikić",
                "zika",
                "123",
                "062123467",
                "Gospodara Vučića 42, Beograd",
                0));
        korisnici.add(new Korisnik(    "Mika",
                "Mikić",
                "mika",
                "123",
                "0654587920",
                "Guncate 50",
                0));
        korisnici.add(new Korisnik(    "Vesna",
                "Vesnić",
                "vesna",
                "123",
                "0641232929",
                "Nova Ulica 10, Mars",
                0));
        korisnici.add(new Korisnik(    "Mitar",
                "Mitrić",
                "mitar",
                "123",
                "065123129",
                "Pilota Mihajla Petrovića 13, Beograd",
                0));
    }
}




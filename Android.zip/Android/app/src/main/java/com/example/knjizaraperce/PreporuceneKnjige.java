package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.knjizaraperce.podaci.Knjiga;
import com.example.knjizaraperce.podaci.Korisnik;
import com.example.knjizaraperce.podaci.Preporuka;

import java.util.Objects;

public class PreporuceneKnjige extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preporucene_knjige);
        Objects.requireNonNull(getSupportActionBar()).hide();
        if(Korisnik.getUlogovaniKorisnik()==null){
            Intent intent = new Intent(this, Prijava.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }

        LinearLayout main = (LinearLayout) findViewById(R.id.main);
        Typeface boldTypeface = Typeface.defaultFromStyle(Typeface.BOLD);
        Typeface italicTypeface = Typeface.defaultFromStyle(Typeface.ITALIC);

        for(Preporuka p: Preporuka.getPreporuke()){
            if(p.getZa().equals(Korisnik.getUlogovaniKorisnik().getKorime())
            && p.getPrikaz()==1){
                Knjiga knj = dohvatiKnjigu(p.getKnjiga());
                if(knj == null) continue;

                LinearLayout n = new LinearLayout(getApplicationContext());
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(800, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(80,30,0,0);
                n.setLayoutParams(np);
                n.setBackgroundColor(Color.parseColor("#FFEF9D"));
                n.setOrientation(LinearLayout.HORIZONTAL);

                ImageView slika = new ImageView(getApplicationContext());
                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(30,10,10,10);
                np.width=300;
                np.height=500;
                slika.setLayoutParams(np);
                Resources res = getResources();
                int resID = res.getIdentifier("@drawable/" + knj.getSlika(), null, getPackageName());
                slika.setImageResource(resID);
                slika.setOnClickListener(new KnjigaClickListener(knj,this));
                n.addView(slika);

                LinearLayout nn = new LinearLayout(getApplicationContext());
                np = new LinearLayout.LayoutParams(800, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(10,30,0,0);
                nn.setLayoutParams(np);
                nn.setBackgroundColor(Color.parseColor("#FFEF9D"));
                nn.setOrientation(LinearLayout.VERTICAL);
                n.addView(nn);

                ImageView x = new ImageView(getApplicationContext());
                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(380,-15,0,0);
                x.setLayoutParams(np);
                x.setImageResource(R.drawable.ic_x);
                x.setOnClickListener(new XClickListener(p,this));
                nn.addView(x);

                TextView naslov = new TextView(getApplicationContext());
                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(0,-60,0,0);
                naslov.setLayoutParams(np);
                naslov.setTypeface(boldTypeface);
                naslov.setText(knj.getNaziv());
                naslov.setTextColor(Color.BLACK);
                naslov.setTextSize(15);
                nn.setOnClickListener(new KnjigaClickListener(knj,this));
                nn.addView(naslov);

                TextView autori = new TextView(getApplicationContext());
                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(0,0,0,0);
                autori.setLayoutParams(np);
                autori.setTypeface(italicTypeface);
                autori.setText(knj.getAutori());
                autori.setTextColor(Color.BLACK);
                autori.setTextSize(12);
                nn.addView(autori);

                if(knj.isPromocija()){
                    LinearLayout nnn = new LinearLayout(getApplicationContext());
                    np = new LinearLayout.LayoutParams(800, ViewGroup.LayoutParams.WRAP_CONTENT);
                    np.setMargins(10,30,0,0);
                    nnn.setLayoutParams(np);
                    nnn.setBackgroundColor(Color.parseColor("#FFEF9D"));
                    nnn.setOrientation(LinearLayout.HORIZONTAL);
                    nn.addView(nnn);

                    TextView staracena = new TextView(getApplicationContext());
                    np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    np.setMargins(0,250,0,0);
                    staracena.setLayoutParams(np);
                    staracena.setTypeface(boldTypeface);
                    staracena.setText(knj.getCena() + " ");
                    staracena.setPaintFlags(staracena.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    staracena.setTextColor(Color.BLACK);
                    staracena.setTextSize(10);
                    nnn.addView(staracena);

                    TextView cena = new TextView(getApplicationContext());
                    np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    np.setMargins(0,250,0,0);
                    cena.setLayoutParams(np);
                    cena.setTypeface(boldTypeface);
                    cena.setText(knj.getPromotivna_cena() + " din.");
                    cena.setTextColor(Color.RED);
                    cena.setTextSize(10);
                    nnn.addView(cena);

                }
                else{
                    TextView staracena = new TextView(getApplicationContext());
                    np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    np.setMargins(0,250,0,0);
                    staracena.setLayoutParams(np);
                    staracena.setTypeface(boldTypeface);
                    staracena.setText(knj.getCena() + " din.");
                    staracena.setTextColor(Color.BLACK);
                    staracena.setTextSize(10);
                    nn.addView(staracena);
                }

                TextView od = new TextView(getApplicationContext());
                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(0,0,0,0);
                od.setLayoutParams(np);
                od.setTypeface(boldTypeface);
                od.setText(getPunoIme(p.getOd()));
                od.setTextColor(Color.BLACK);
                od.setTextSize(10);
                nn.addView(od);

                main.addView(n);
            }
        }
    }

    public Knjiga dohvatiKnjigu(int id){
        for (Knjiga k:Knjiga.getKnjige()){
            if(k.getId()==id) return k;
        }
        return null;
    }

    private String getPunoIme(String korime){
        for(Korisnik k:Korisnik.getKorisnici()){
            if(k.getKorime().equals(korime)) return "Preporučeno od " + k.getIme() + " " + k.getPrezime() + " (" + k.getKorime() + ")";
        }
        return "Korisnik: Nije pronađen";
    }

    public void meni(View view){
        Intent intent = new Intent(this, Meni.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }
}

class XClickListener implements View.OnClickListener
{
    Preporuka var; Context context;
    public XClickListener(Preporuka var, Context context) {
        this.var = var;
        this.context=context;
    }

    @Override
    public void onClick(View v)
    {
        var.setPrikaz(0);

        Intent intent = new Intent(context, PreporuceneKnjige.class);
        ((Activity)context).startActivity(intent);
        ((Activity)context).overridePendingTransition(0, 0);
        ((Activity)context).finish();
    }
}


class KnjigaClickListener implements View.OnClickListener
{
    Knjiga var; Context context;
    public KnjigaClickListener(Knjiga var, Context context) {
        this.var = var;
        this.context=context;
    }

    @Override
    public void onClick(View v)
    {
        Knjiga.setSelektovanaKnjiga(var);

        Intent intent = new Intent(context, DetaljiKnjige.class);
        ((Activity)context).startActivity(intent);
        ((Activity)context).overridePendingTransition(0, 0);
        ((Activity)context).finish();
    }
}
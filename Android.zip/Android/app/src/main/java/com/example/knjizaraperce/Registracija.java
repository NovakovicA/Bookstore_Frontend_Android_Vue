package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;

import com.example.knjizaraperce.podaci.Korisnik;

import java.util.Objects;

public class Registracija extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registracija);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    public void login(View view){
        Intent intent = new Intent(this, Prijava.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void registruj(View view){
        String ime=((EditText)findViewById(R.id.ime)).getText().toString();
        String prezime=((EditText)findViewById(R.id.prezime)).getText().toString();
        String brojTelefona=((EditText)findViewById(R.id.brojtelefona)).getText().toString();
        String adresa=((EditText)findViewById(R.id.adresa)).getText().toString();
        String korime=((EditText)findViewById(R.id.korime)).getText().toString();
        String lozinka=((EditText)findViewById(R.id.lozinka)).getText().toString();

        if(ime.equals("") || prezime.equals("") ||brojTelefona.equals("") ||adresa.equals("") ||korime.equals("") ||lozinka.equals("")){
            Poruka.prikaziGresku(this, "Morate uneti sve podatke.");
            return;
        }

        for(Korisnik k:Korisnik.getKorisnici()){
            if(k.getKorime().equals(korime)) {
                Poruka.prikaziGresku(this, "Već je registrovano dato korisničko ime.");
                return;
            }
        }

        Korisnik.insert(new Korisnik(ime,prezime,korime,lozinka,brojTelefona,adresa,0));
        Poruka.prikaziUspesno(this,"Uspešno registrovan novi korisnik.");

        Intent intent = new Intent(this, Prijava.class);
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
            }
        }, 3000);
    }
}
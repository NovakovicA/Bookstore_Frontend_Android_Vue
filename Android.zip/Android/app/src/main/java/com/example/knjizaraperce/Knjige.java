package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.knjizaraperce.podaci.Knjiga;
import com.example.knjizaraperce.podaci.Korisnik;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Knjige extends AppCompatActivity {

    private static List<Knjiga> promocije;
    private static List<Knjiga> dostupne;

    private int promocijepoz=0;
    private int dostupnepoz=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_knjige);
        Objects.requireNonNull(getSupportActionBar()).hide();
        if(Korisnik.getUlogovaniKorisnik()==null){
            Intent intent = new Intent(this, Prijava.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }
        TextView staracena=((TextView)findViewById(R.id.pstaracena));
        staracena.setPaintFlags(staracena.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

        promocije = new LinkedList<Knjiga>();
        dostupne = new LinkedList<Knjiga>();

        for(Knjiga k:Knjiga.getKnjige()){
            if(k.isPromocija()) {promocije.add(k);}
            else {dostupne.add(k);}
        }
        prikaziPromociju(promocije.get(promocijepoz));
        prikaziDostupnu(dostupne.get(dostupnepoz));
    }


    public void meni(View view){
        Intent intent = new Intent(this, Meni.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    private void prikaziPromociju(Knjiga k){
        if(!k.isPromocija()) return;
        ImageView slika = (ImageView) findViewById(R.id.pslika);
        TextView naslov = (TextView) findViewById(R.id.pnaslov);
        TextView autori = (TextView) findViewById(R.id.pautori);
        TextView staracena = (TextView) findViewById(R.id.pstaracena);
        TextView cena = (TextView) findViewById(R.id.pcena);

        Resources res = getResources();
        int resID = res.getIdentifier("@drawable/" +k.getSlika() , null, getPackageName());
        slika.setImageResource(resID);


        naslov.setText( " " + k.getNaziv() + " ");
        autori.setText(k.getAutori());
        staracena.setText(k.getCena() + "");
        cena.setText(" " +k.getPromotivna_cena() + " din.");
    }

    private void prikaziDostupnu(Knjiga k){
        if(k.isPromocija()) return;
        ImageView slika = (ImageView) findViewById(R.id.dslika);
        TextView naslov = (TextView) findViewById(R.id.dnaslov);
        TextView autori = (TextView) findViewById(R.id.dautori);
        TextView cena = (TextView) findViewById(R.id.dcena);

        Resources res = getResources();
        int resID = res.getIdentifier("@drawable/" + k.getSlika(), null, getPackageName());
        slika.setImageResource(resID);

        naslov.setText( " " + k.getNaziv() + " ");
        autori.setText(k.getAutori());
        cena.setText(" " +k.getCena() + " din.");
    }

    private float x1,x2,y2;
    static final int MIN_DISTANCE = 150;


    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        switch(event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                x1=event.getX();
                break;
            case MotionEvent.ACTION_UP:
                x2=event.getX();
                y2=event.getY();
                float deltaX = x2 - x1;

                Display display = getWindowManager().getDefaultDisplay();
                Point size = new Point();
                display.getSize(size);
                int height = size.y;

                if (Math.abs(deltaX) > MIN_DISTANCE)
                {
                    if(y2<height/2+300) {
                        if (x2 < x1) {
                            if(promocijepoz<promocije.size()-1) {promocijepoz++; prikaziPromociju(promocije.get(promocijepoz));}
                        }
                        else {
                            if(promocijepoz>0) {promocijepoz--; prikaziPromociju(promocije.get(promocijepoz));}
                        }
                    }
                    else{
                        if (x2 < x1) {
                            if(dostupnepoz<dostupne.size()-1) {dostupnepoz++; prikaziDostupnu(dostupne.get(dostupnepoz));}
                        }
                        else {
                            if(dostupnepoz>0) {dostupnepoz--; prikaziDostupnu(dostupne.get(dostupnepoz));}
                        }
                    }
                }
                break;
        }
        return super.onTouchEvent(event);
    }

    public void otvoriPromociju(View view) {
        Knjiga.setSelektovanaKnjiga(promocije.get(promocijepoz));
        Intent intent = new Intent(this, DetaljiKnjige.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void otvoriDostupnu(View view){
        Knjiga.setSelektovanaKnjiga(dostupne.get(dostupnepoz));
        Intent intent = new Intent(this, DetaljiKnjige.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }


}
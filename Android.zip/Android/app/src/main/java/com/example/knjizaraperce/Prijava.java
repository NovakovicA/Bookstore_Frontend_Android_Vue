package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;

import com.example.knjizaraperce.podaci.Knjiga;
import com.example.knjizaraperce.podaci.Komentar;
import com.example.knjizaraperce.podaci.Korisnik;
import com.example.knjizaraperce.podaci.Preporuka;

import java.util.Objects;

public class Prijava extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prijava);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Korisnik.init();
        Knjiga.init();
        Komentar.init();
        Preporuka.init();
    }

    public void prijava(View view) {
        String k=((EditText)findViewById(R.id.korisnickoime)).getText().toString();
        String l=((EditText)findViewById(R.id.lozinka)).getText().toString();

            if(Korisnik.login(k,l)==true){
                Poruka.prikaziUspesno(this, "Uspešno ste prijavljeni.");
                Intent intent = new Intent(this, Knjige.class);
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(intent);
                        overridePendingTransition(0, 0);
                        finish();
                    }
                }, 3000);
                return;
            }
        Poruka.prikaziGresku(this, "Pogrešno korisničko ime/lozinka.");
    }

    public void registracija(View view){
        Intent intent = new Intent(this, Registracija.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }
}
package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.knjizaraperce.podaci.Korisnik;

import java.util.Objects;

public class Podaci1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_podaci1);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Korisnik k = Korisnik.getUlogovaniKorisnik();
        if(k==null){
            Intent intent = new Intent(this, Prijava.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }
        else{
            ((EditText)findViewById(R.id.ime)).setText(k.getIme());
            ((EditText)findViewById(R.id.prezime)).setText(k.getPrezime());
            ((EditText)findViewById(R.id.brojtelefona)).setText(k.getBrojTelefona());
            ((EditText)findViewById(R.id.adresa)).setText(k.getAdresa());
        }
    }

    public void meni(View view){
        Intent intent = new Intent(this, Meni.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void sacuvaj(View view){
        String ime=((EditText)findViewById(R.id.ime)).getText().toString();
        String prezime=((EditText)findViewById(R.id.prezime)).getText().toString();
        String brojTelefona=((EditText)findViewById(R.id.brojtelefona)).getText().toString();
        String adresa=((EditText)findViewById(R.id.adresa)).getText().toString();

        if(ime.equals("") || prezime.equals("") || brojTelefona.equals("") || adresa.equals("")){
            Poruka.prikaziGresku(this, "Morate uneti sve podatke.");
            return;
        }
        Korisnik k = Korisnik.getUlogovaniKorisnik();
        k.setIme(ime);
        k.setPrezime(prezime);
        k.setBrojTelefona(brojTelefona);
        k.setAdresa(adresa);
        Poruka.prikaziUspesno(this,"Uspešno promenjeni podaci.");
    }
}
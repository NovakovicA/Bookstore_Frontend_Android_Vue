package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.knjizaraperce.podaci.Komentar;
import com.example.knjizaraperce.podaci.Korisnik;
import com.example.knjizaraperce.podaci.Preporuka;

import java.util.Objects;

public class Podaci2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_podaci2);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Korisnik k = Korisnik.getUlogovaniKorisnik();
        if(k==null){
            Intent intent = new Intent(this, Prijava.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }
        else{
            ((EditText)findViewById(R.id.novokorime)).setText(k.getKorime());
        }
    }


    public void meni(View view){
        Intent intent = new Intent(this, Meni.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void sacuvaj(View view) {
        String novokorime=((EditText)findViewById(R.id.novokorime)).getText().toString();
        String trenutnalozinka=((EditText)findViewById(R.id.trenutnalozinka)).getText().toString();
        String novalozinka=((EditText)findViewById(R.id.novalozinka)).getText().toString();

        Korisnik k = Korisnik.getUlogovaniKorisnik();

        if(novokorime.equals("") || trenutnalozinka.equals("") || novalozinka.equals("")){
            Poruka.prikaziGresku(this,"Morate popuniti sve podatke.");
            return;
        }
        if(!trenutnalozinka.equals(k.getLozinka())){
            Poruka.prikaziGresku(this,"Neispravna trenutna lozinka.");
            return;
        }

        for(Korisnik kor:Korisnik.getKorisnici()){
            if(kor.getKorime().equals(novokorime) && !Korisnik.getUlogovaniKorisnik().getKorime().equals(kor.getKorime())){
                Poruka.prikaziGresku(this,"Dato korisničko ime već postoji.");
                return;
            }
        }

        for(Komentar kom: Komentar.getKomentari()){
            if(kom.getKorisnik().equals(Korisnik.getUlogovaniKorisnik().getKorime())){
                kom.setKorisnik(novokorime);
            }
        }

        for(Preporuka prep: Preporuka.getPreporuke()){
            if(prep.getZa().equals(Korisnik.getUlogovaniKorisnik().getKorime())){
                prep.setZa(novokorime);
            }
            else if(prep.getOd().equals(Korisnik.getUlogovaniKorisnik().getKorime())){
                prep.setOd(novokorime);
            }
        }

        k.setKorime(novokorime);
        k.setLozinka(novalozinka);

        Poruka.prikaziUspesno(this,"Uspešno sačuvani podaci.");
    }

}
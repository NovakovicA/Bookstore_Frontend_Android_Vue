package com.example.knjizaraperce.podaci;

import java.util.LinkedList;
import java.util.List;

public class Knjiga {
    private int id;
    private String naziv;
    private String autori;
    private int cena;
    private boolean promocija;
    private int promotivna_cena;
    private int broj_strana;
    private int godina_izdanja;
    private String opis;
    private String slika;

    private static List<Knjiga> knjige = new LinkedList<>();
    private static Knjiga selektovanaKnjiga;

    public Knjiga(int id, String naziv, String autori, int cena, boolean promocija, int promotivna_cena, int broj_strana, int godina_izdanja, String opis, String slika) {
        this.id = id;
        this.naziv = naziv;
        this.autori = autori;
        this.cena = cena;
        this.promocija = promocija;
        this.promotivna_cena = promotivna_cena;
        this.broj_strana = broj_strana;
        this.godina_izdanja = godina_izdanja;
        this.opis = opis;
        this.slika = slika;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getAutori() {
        return autori;
    }

    public void setAutori(String autori) {
        this.autori = autori;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public boolean isPromocija() {
        return promocija;
    }

    public void setPromocija(boolean promocija) {
        this.promocija = promocija;
    }

    public int getPromotivna_cena() {
        return promotivna_cena;
    }

    public void setPromotivna_cena(int promotivna_cena) {
        this.promotivna_cena = promotivna_cena;
    }

    public int getBroj_strana() {
        return broj_strana;
    }

    public void setBroj_strana(int broj_strana) {
        this.broj_strana = broj_strana;
    }

    public int getGodina_izdanja() {
        return godina_izdanja;
    }

    public void setGodina_izdanja(int godina_izdanja) {
        this.godina_izdanja = godina_izdanja;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getSlika() {
        return slika;
    }

    public void setSlika(String slika) {
        this.slika = slika;
    }

    public static List<Knjiga> getKnjige() {
        return knjige;
    }

    public static void insert(Knjiga k){
        knjige.add(k);
    }

    public static void init(){
        if(!knjige.isEmpty()) return;
        knjige.add(new Knjiga(        0,
                "Frankenštajn",
                "Meri Šeli",
                1500,
                true,
                1000,
                312,
                2020,
                "Frankenštajn ili Moderni Prometej Meri Šeli jedan je od najčitanijih romana svih vremena. To je priča o Viktoru Frankenštajnu, naučniku koji je želeo da otkrije tajnu života a stvorio strašno čudovište. Ono je postalo otelotvorenje užasa i kazne koja sledi kad se prekorače moralne granice ljudskog napretka."+
                "Poput Prometeja, Viktor Frankenštajn je pobunjenik koji veruje u vlastite tvoračke potencijale i ima smelosti da prevaziđe ljudska ograničenja. Njegova intelektualna znatiželja i ambicija ne doprinose društvu već vode u propast i, kao njegov mitski preteča, on biva kažnjen zbog potrage za zabranjenim znanjem."+
                "Još od objavljivanja 1818. čitaoci su bili fascinirani Frankenštajnovim čudovištem i zaintrigirani moralnim i etičkim pitanjima koja je roman pokrenuo. Ovaj gotski roman i klasik engleske književnosti tako je prerastao u književni mit, koji i danas živi kroz mnogobrojne pozorišne, filmske i medijske adaptacije.",
        "knjiga1"));
        knjige.add(new Knjiga(
                1,
                "Srpske junačke pesme",
                "Vuk Karadžić",
                1200,
                true,
                900,
                568,
                2021,
                "Izbor najpoznatijih narodnih epskih pesama koje je sakupio i u više knjiga objavio Vuk Stefanović Karadžić. One predstavljaju dragocenu riznicu srpske istorije, književne tradicije i narodne mudrosti. Svojom originalnošću, poetičnošću i skladom očarale su evropsku literarnu elitu Vukovog vremena, a danas su jedan od najvažnijih segmenata očuvanja i negovanja nacionalnog identiteta."+
                "„Svi pokušaji klasifikacije srpske narodne poezije polaze od Vukove periodizacije i sistematizacije građe. Osnovni Vukovi kriterijumi za podelu vrsta narodne poezije jesu namena, način i okolnosti izvođenja pesama: ’Sve su naše narodne pjesme razdijeljene na pjesme junačke, koje ljudi pjevaju uz gusle, i na ženske, koje pjevaju ne samo žene i đevojke, nego i muškarci, osobito momčad, i to najviše po dvoje u jedan glas.’"+
        "Vuk Karadžić u osnovi razvrstava epsku građu prema tematsko-hronološkom kriterijumu na tri grupe: pesme junačke najstarije, do propasti srpske srednjovekovne države u 15. veku (Srpske narodne pjesme, II knjiga), pesme srednjih vremena, o hajdučkim i uskočkim četovanjima do 18. veka (III knjiga) i pesme novijih vremena, o ustaničkim događajima u Srbiji, kao i o crnogorskim borbama za oslobođenje u 18. i 19. veku (IV knjiga)."+
        "Osnovni je zadatak epske pesme, još od najstarijih epova čovečanstva, da sačuva spomen o velikim junacima i znamenitim događajima u vremenu i prostoru, i da ih ostavi potomstvu kao svetle primere ’čojstva i junaštva’, koji uz to imaju i agitacioni karakter u svim relevantnim nacionalnim zbivanjima.“"+
        "– Iz predgovora prof. dr Boška Suvajdžića",
        "knjiga2"
        ));
        knjige.add(new Knjiga(
                2,
                "Zločin i kazna",
                "Fjodor Dostojevski",
                800,
                false,
                0,
                714,
                2019,
                "Remek-delo ruske književnosti, Zločin i kazna svrstalo je Dostojevskog u red najznačajnijih svetskih romanopisaca. Oslanjajući se na sopstveno iskustvo iz zatvorskih dana, u grozničavom tonu i na ubedljiv način, autor pripoveda priču o Raskoljnikovu – siromašnom studentu mučenom nihilizmom i borbom između dobra i zla. Verujući za sebe da je iznad zakona i ubeđen u to da viši ciljevi opravdavaju sredstvo, on brutalno ubija lihvarku za koju kaže da je „ništavna, zla, bolesna baba koja nikome nije potrebna... koja ni sama ne zna zašto živi i koja će ionako već danas-sutra umreti“. Skrhan osećajem krivice, on će otpočeti proces pokajanja koji će mu korenito promeniti pogled na svet."+
                "„Dostojevski je pisao prozu o zaista važnim pitanjima. Pisao je prozu o identitetu, moralnoj vrednosti, smrti, volji, odnosu telesne i duhovne ljubavi, pohlepi, slobodi, opsesiji, razumu, veri, samoubistvu. A to je izveo bez ikakvog svođenja svojih likova na glasnogovornike ili svojih knjiga na traktate. On je uvek obuzet pitanjem šta znači biti ljudsko biće – odnosno kako biti prava osoba, neko čiji život prožimaju vrednosti i principi – a ne tek izrazito pronicljiva životinja sposobna za samoodržanje.“ Dejvid Foster Volas",
                "knjiga3"
        ));
        knjige.add(new Knjiga(
                        3,
                        "Napoleon",
                        "Pol Džonson",
                        1500,
                        false,
                        0,
                        184,
                        2007,
                        "Napoleon je knjiga za sve one koji su spremni da istoriju sagledaju kroz prizmu novih i prilično radikalnih ideja. Pol Džonson prikazuje Napoleona kakvog nećete sresti u klasičnim istorijskim udžbenicima i poziva vas da ponovo razmislite o tome kako istorija može da se tumači."+
                        "Napoleon i Francuzi su iz sasvim praktičnih razloga nagovestili užase dvadesetog veka. Napoleon je izumeo apsolutnu tiraniju zasnovanu na ideji prava da više intelektualne elite nametnu demokratske standarde prostim ljudima, dok su Francuzi giljotinom sprovodili „duh revolucije“."+
                "Pol Džonson ukratko ističe Napoleonov vojni genije na kojem su mu zavideli svi potonji generali, ali ga ipak možda usavršili Grant, Romel i Paton, dok sa druge strane ruši legendu navodeći primere Napoleonovih velikih strateških promašaja i previda.",
                "knjiga4"
        ));
        knjige.add(new Knjiga(
                4,
                "Tramp: cela priča",
                "Mark Fišer, Majkl Krejniš",
                1700,
                true,
                1150,
                496,
                2016,
                "Ambicija, ego, novac i moć na američki način."+
                "„Čista budalaština. Ništa oni ne znaju o meni. Ja tu knjigu sigurno neću čitati“ – DONALD TRAMP, o ovoj knjizi u izjavi New York Postu, 12. aprila 2016."+
                "„Ako knjiga bude loša, verovatno će mi naneti štetu. Zato ne treba da bude loša knjiga. Ako već hoćete da je napišete, mogli bismo onda zajedno da se potrudimo i da je napišemo kako treba.“ – TRAMP, autorima knjige, 21. aprila 2016."+
                "„Ovo je veoma zabavno. Možemo da pričamo koliko god hoćete.“ – TRAMP, autorima knjige, 21. aprila 2016."+
                "„Ako napišete negativnu knjigu o meni, pazite: ona vam se neće bogzna kako prodavati. A koliko vidim, biće verovatno negativna knjiga. Ma nek ide život, šta da se radi.“ – TRAMP, autorima knjige, 9. juna 2016.",
        "knjiga5"
        ));
        knjige.add(new Knjiga(
                5,
                "Ilon Mask",
                "Ešli Vens",
                1300,
                false,
                0,
                448,
                2017,
                "„Iscrpna priča o čoveku koji bi mogao imati najveći uticaj na ljudski rod. Ukoliko Mask odvede čovečanstvo na Mars, ovo će biti osnivački dokument te planete.“ Bred Stoun"+
                "Prvo mesto na listi poslovnih bestselera New York Timesa."+
                "Prvo mesto na Amazonovoj listi poslovnih i preduzetničkih bestselera."+
                "Amazonova knjiga godine (Poslovanje i investicije)."+
                "Najbolja poslovna knjiga Wall Street Journala za 2015. godinu."+
                "U knjizi Ilon Mask: Tesla, SpaceX i potraga za fantastičnom budućnošću, tehnološki novinar Ešli Vens daje prvi insajderski pogled na izuzetan život i doba najneustrašivijeg preduzetnika iz Silicijumske doline - današnjeg amalgama legendarnih pronalazača i industrijalaca poput Tomasa Edisona, Henrija Forda, Hauarda Hjuza i Stiva Džobsa. Ekskluzivnim pristupom Maskovom privatnom životu, porodici i prijateljima, knjiga opisuje preduzetnikovo putovanje od teškog detinjstva u Južnoj Africi do samog vrha globalnog poslovnog sveta. Vens je u razgovorima sa Maskom proveo više od 30 sati i intervjuisao gotovo 300 ljudi kako bi predočio istoriju njegovih kompanija koje su promenile svet - Pejpal, Tesla motors, SpaceX, Solarsiti - i opisao čoveka koji je obnovio američku industriju, podstakao uspon do viših nivoa inovacija, i pritom stekao mnogo neprijatelja."+
                "„Masku se mora priznati: niko mu nije ni nalik.“ New York Times"+
                "„Neodoljiva pripovest o tome kako su začete i rođene Ilonove revolucionarne zamisli, koje su sada u procvatu.“ dr Dž. Krejg Venter, pronalazač sekvence ljudskog genoma i tvorac sintetičkog života"+
                "„Najbolja knjiga koju sam pročitao posle više godina.“ Don Grejam, izdavač Washington Posta"+
                "„Fascinatno i vrhunski istraženo.“ Guardian",
        "knjiga6"
        ));
        knjige.add(new Knjiga(
                6,
                "Antička filozofija",
                "Džulija Enas",
                1500,
                true,
                1000,
                184,
                2019,
                "Kratko, jasno, sveobuhvatno."+
                        "Kada je počela ljubav antičkih mislilaca prema mudrosti, koju sada prepoznajemo kao filozofsku? Kako je ta tradicija nastala? Šta su antički filozofi mislili o sukobu razuma i emocija u čoveku? Ima li nekih tema koje su zaokupljale antičke filozofe a koje ne dotiču savremene? Šta možemo da naučimo iz razmišljanja antičkih filozofa? Kako se prihvatanje antičke filozofije menjalo tokom vremena? Da li je zapadna tradicija isticanja značaja razuma, nasleđena od antičke filozofije, umanjila uticaj drugih filozofskih tradicija na Zapadu?"+
                "Početke antičke filozofije možemo da pratimo od šestog veka stare ere i ona traje sve do propasti Zapadnog rimskog carstva i pada Vizantijskog carstva. Autorka se usredsređuje na važne odlike ove filozofije, predstavlja debate vođene u antičko doba, obrađuje mnoštvo tema koje su pokretali tadašnji filozofi i stilove njihovih razmišljanja, izlažući osnovne principe antičke filozofije kao aktuelnu i živu misao koja i danas ima svoju vrednost.",
        "knjiga7"
        ));
    }

    public static Knjiga getSelektovanaKnjiga() {
        return selektovanaKnjiga;
    }

    public static void setSelektovanaKnjiga(Knjiga selektovanaKnjiga) {
        Knjiga.selektovanaKnjiga = selektovanaKnjiga;
    }
}

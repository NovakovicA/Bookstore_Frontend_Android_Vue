package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.knjizaraperce.podaci.Korisnik;

import java.util.Objects;

public class Meni extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meni);
        Objects.requireNonNull(getSupportActionBar()).hide();
        if(Korisnik.getUlogovaniKorisnik()==null){
            Intent intent = new Intent(this, Prijava.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }
        ((TextView)findViewById(R.id.imeiprezime)).setText(" " + Korisnik.getUlogovaniKorisnik().getIme() + " "
                + Korisnik.getUlogovaniKorisnik().getPrezime() + ",kupac ");
    }

    public void knjige(View view){
        Intent intent = new Intent(this, Knjige.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void preporuke(View view){
        Intent intent = new Intent(this, PreporuceneKnjige.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void podaci1(View view){
        Intent intent = new Intent(this, Podaci1.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void podaci2(View view){
        Intent intent = new Intent(this, Podaci2.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void odjava(View view){
        Korisnik.logoff();
        Intent intent = new Intent(this, Prijava.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

}
package com.example.knjizaraperce;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class Poruka {

    public static void prikaziGresku(Context context, String greska){
        new AlertDialog.Builder(context,R.style.greska).setMessage(greska).setPositiveButton(
                "ok", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }

    public static void prikaziUspesno(Context context, String uspesno){
        new AlertDialog.Builder(context,R.style.uspesno).setMessage(uspesno).setPositiveButton(
                "ok", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }
}

package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.knjizaraperce.podaci.Knjiga;
import com.example.knjizaraperce.podaci.Korisnik;
import com.example.knjizaraperce.podaci.Preporuka;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class PreporuciKnjigu extends AppCompatActivity {

    public static List<ImageView> slike = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preporuci_knjigu);
        Objects.requireNonNull(getSupportActionBar()).hide();
        if(Korisnik.getUlogovaniKorisnik()==null){
            Intent intent = new Intent(this, Prijava.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }
        else if(Knjiga.getSelektovanaKnjiga()==null){
            Intent intent = new Intent(this, Knjige.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }
        ImageView slika = (ImageView) findViewById(R.id.slika);
        TextView naslov = (TextView) findViewById(R.id.naslov);
        TextView autori = (TextView) findViewById(R.id.autori);
        TextView cena = (TextView) findViewById(R.id.cena);

        Resources res = getResources();
        int resID = res.getIdentifier("@drawable/" + Knjiga.getSelektovanaKnjiga().getSlika(), null, getPackageName());
        slika.setImageResource(resID);

        naslov.setText( " " + Knjiga.getSelektovanaKnjiga().getNaziv() + " ");
        autori.setText(Knjiga.getSelektovanaKnjiga().getAutori());
        cena.setText(" " +Knjiga.getSelektovanaKnjiga().getCena() + " din.");


        LinearLayout main = (LinearLayout) findViewById(R.id.main);
        Typeface boldTypeface = Typeface.defaultFromStyle(Typeface.BOLD);
        slike.clear();


        LinearLayout n = new LinearLayout(getApplicationContext());
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(900, ViewGroup.LayoutParams.WRAP_CONTENT);
        np.setMargins(100,30,0,0);
        n.setLayoutParams(np);
        n.setBackgroundColor(Color.parseColor("#FFEF9D"));
        n.setOrientation(LinearLayout.VERTICAL);

        int ind=0;
        for(Korisnik kor:Korisnik.getKorisnici()){
            if(!kor.getKorime().equals(Korisnik.getUlogovaniKorisnik().getKorime())){
                LinearLayout nn = new LinearLayout(getApplicationContext());
                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(100,30,0,0);
                np.gravity=Gravity.RIGHT;
                nn.setLayoutParams(np);
                nn.setOrientation(LinearLayout.HORIZONTAL);

                TextView ko = new TextView(getApplicationContext());
                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.setMargins(0,0,100,20);
                ko.setLayoutParams(np);
                ko.setTypeface(boldTypeface);
                ko.setText(getPunoIme(kor));
                ko.setTextColor(Color.BLACK);
                ko.setTextSize(15);
                nn.addView(ko);

                ImageView sl = new ImageView(getApplicationContext());
                if(proveriPostojanjePreporuke(kor)) sl.setImageResource(R.drawable.ic_user_check);
                else sl.setImageResource(R.drawable.ic_user_x);

                np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                sl.setLayoutParams(np);
                sl.setOnClickListener(new PreporukaClickListener(kor,ind,this));
                nn.addView(sl);
                slike.add(sl);
                n.addView(nn);
                ind++;
            }
        }
        main.addView(n);
    }


    private String getPunoIme(Korisnik k){
           return "Korisnik: " + k.getIme() + " " + k.getPrezime() + " (" + k.getKorime() + ")";
    }

    public static boolean proveriPostojanjePreporuke(Korisnik k){
        for(Preporuka p:Preporuka.getPreporuke()){
            if(p.getZa().equals(k.getKorime()) && p.getOd().equals(Korisnik.getUlogovaniKorisnik().getKorime())
            && p.getKnjiga()==Knjiga.getSelektovanaKnjiga().getId()) return true;
        }
        return false;
    }

    public static void napraviPreporuku(Korisnik k){
        Preporuka.getPreporuke().add(new Preporuka(
                Korisnik.getUlogovaniKorisnik().getKorime(),
                k.getKorime(),
                Knjiga.getSelektovanaKnjiga().getId(),
                1
                )
        );
    }

    public static void izbrisiPreporuku(Korisnik k){
        Preporuka p=null;
        List<Preporuka> rest = new LinkedList<>();

        for(int i=0;i<Preporuka.getPreporuke().size();i++){
            p=Preporuka.getPreporuke().get(i);
            if (!(p.getOd().equals(Korisnik.getUlogovaniKorisnik().getKorime()) &&
            p.getZa().equals(k.getKorime()) && p.getKnjiga()==Knjiga.getSelektovanaKnjiga().getId())){
                rest.add(p);
            }
        }
        Preporuka.getPreporuke().clear();
        for(Preporuka pp:rest) {
            Preporuka.getPreporuke().add(pp);
        }
    }

    public void meni(View view){
        Intent intent = new Intent(this, Meni.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }


}

class PreporukaClickListener implements View.OnClickListener {
    Korisnik k;
    int ind;
    Context context;

    public PreporukaClickListener(Korisnik k, int ind, Context context) {
        this.k = k;
        this.ind = ind;
        this.context=context;
    }

    @Override
    public void onClick(View v) {
        //Toast.makeText(context,ind + " " + k.getKorime(), Toast.LENGTH_SHORT).show();
        if (PreporuciKnjigu.proveriPostojanjePreporuke(k)) {
            PreporuciKnjigu.izbrisiPreporuku(k);
            PreporuciKnjigu.slike.get(ind).setImageResource(R.drawable.ic_user_x);
        }
        else{
                PreporuciKnjigu.napraviPreporuku(k);
                PreporuciKnjigu.slike.get(ind).setImageResource(R.drawable.ic_user_check);
            }
        }
}

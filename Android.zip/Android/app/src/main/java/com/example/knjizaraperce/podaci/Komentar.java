package com.example.knjizaraperce.podaci;

import java.util.LinkedList;
import java.util.List;

public class Komentar {
    private int knjiga;
    private String korisnik;
    private int ocena;
    private String sadrzaj;

    private static List<Komentar> komentari = new LinkedList<>();

    public Komentar(int knjiga, String korisnik, int ocena, String sadrzaj) {
        this.knjiga = knjiga;
        this.korisnik = korisnik;
        this.ocena = ocena;
        this.sadrzaj = sadrzaj;
    }

    public int getKnjiga() {
        return knjiga;
    }

    public void setKnjiga(int knjiga) {
        this.knjiga = knjiga;
    }

    public String getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(String korisnik) {
        this.korisnik = korisnik;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public String getSadrzaj() {
        return sadrzaj;
    }

    public void setSadrzaj(String sadrzaj) {
        this.sadrzaj = sadrzaj;
    }

    public static List<Komentar> getKomentari() {
        return komentari;
    }

    public void insert(Komentar k){
        komentari.add(k);
    }

    public static void init(){
        if(!komentari.isEmpty()) return;
        komentari.add(new Komentar(
                0,
                "pera",
                5,
                "extra"
        ));
        komentari.add(new Komentar(
                0,
                "zika",
                3,
                "nije lose"
        ));
        komentari.add(new Komentar(
                0,
                "vesna",
                1,
                "ne sviđa mi se :("
        ));
        komentari.add(new Komentar(
                2,
                "zika",
                5,
                "dobra"
        ));
        komentari.add(new Komentar(
                2,
                "mika",
                4,
                "super knjiga"
        ));
    }
}

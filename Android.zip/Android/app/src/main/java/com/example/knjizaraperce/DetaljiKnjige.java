package com.example.knjizaraperce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup.LayoutParams;


import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.example.knjizaraperce.podaci.Knjiga;
import com.example.knjizaraperce.podaci.Komentar;
import com.example.knjizaraperce.podaci.Korisnik;


import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class DetaljiKnjige extends AppCompatActivity {

    public static List<ImageView> zvezde=new LinkedList<ImageView>();
    public static int ocena=5;
    public static TextView komentar=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalji_knjige);
        Objects.requireNonNull(getSupportActionBar()).hide();
        if(Korisnik.getUlogovaniKorisnik()==null){
            Intent intent = new Intent(this, Prijava.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }
        else if(Knjiga.getSelektovanaKnjiga()==null){
            Intent intent = new Intent(this, Knjige.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
            this.finish();
        }

        ImageView slika = (ImageView) findViewById(R.id.slika);
        TextView naslov = (TextView) findViewById(R.id.naslov);
        TextView autori = (TextView) findViewById(R.id.autori);
        TextView cena = (TextView) findViewById(R.id.cena);
        TextView brojstrana = (TextView) findViewById(R.id.brojstrana);
        TextView god = (TextView) findViewById(R.id.god);
        TextView opis = (TextView) findViewById(R.id.opis);

        Resources res = getResources();
        int resID = res.getIdentifier("@drawable/" + Knjiga.getSelektovanaKnjiga().getSlika(), null, getPackageName());
        slika.setImageResource(resID);

        naslov.setText( " " + Knjiga.getSelektovanaKnjiga().getNaziv() + " ");
        autori.setText( " " + Knjiga.getSelektovanaKnjiga().getAutori() + " ");
        if(Knjiga.getSelektovanaKnjiga().isPromocija()){
            cena.setText( "Promotivna cena: " + Knjiga.getSelektovanaKnjiga().getPromotivna_cena() + "din. ");
        }
        else{
            cena.setText( "Cena: " + Knjiga.getSelektovanaKnjiga().getCena() + "din. ");
        }
        brojstrana.setText( "Broj strana: " + Knjiga.getSelektovanaKnjiga().getBroj_strana() + " ");
        god.setText( "Godina izdanja: " + Knjiga.getSelektovanaKnjiga().getGodina_izdanja() + ". ");
        opis.setText( Knjiga.getSelektovanaKnjiga().getOpis());

        LinearLayout main = (LinearLayout) findViewById(R.id.main);
        Typeface boldTypeface = Typeface.defaultFromStyle(Typeface.BOLD);

        for(Komentar k:Komentar.getKomentari()){
            if(k.getKnjiga()==Knjiga.getSelektovanaKnjiga().getId()){

                LinearLayout n = new LinearLayout(getApplicationContext());
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(800,LayoutParams.WRAP_CONTENT);
                np.setMargins(10,20,0,0);
                n.setLayoutParams(np);
                n.setBackgroundColor(Color.parseColor("#FFEF9D"));
                n.setOrientation(LinearLayout.VERTICAL);

                TextView k1 = new TextView(getApplicationContext());
                k1.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
                k1.setTypeface(boldTypeface);
                k1.setText(" " + getPunoIme(k.getKorisnik()));
                k1.setTextColor(Color.BLACK);
                k1.setTextSize(15);
                n.addView(k1);

                LinearLayout nn = new LinearLayout(getApplicationContext());
                LinearLayout.LayoutParams npp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
                npp.setMargins(0,0,0,0);
                nn.setLayoutParams(np);
                nn.setBackgroundColor(Color.parseColor("#FFEF9D"));
                nn.setOrientation(LinearLayout.HORIZONTAL);

                TextView ko = new TextView(getApplicationContext());
                ko.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
                ko.setTypeface(boldTypeface);
                ko.setText("Ocena:");
                ko.setTextColor(Color.BLACK);
                ko.setTextSize(15);
                nn.addView(ko);

                for(int i=1;i<=k.getOcena();i++){
                    ImageView starfull = new ImageView(getApplicationContext());
                    starfull.setImageResource(R.drawable.ic_star);
                    starfull.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
                    nn.addView(starfull);
                }
                for(int i=1;i<=5-k.getOcena();i++){
                    ImageView starfull = new ImageView(getApplicationContext());
                    starfull.setImageResource(R.drawable.ic_star_empty);
                    starfull.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
                    nn.addView(starfull);
                }
                n.addView(nn);

                TextView k2 = new TextView(getApplicationContext());
                k2.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
                k2.setTypeface(boldTypeface);
                k2.setText(" Komentar:" + k.getSadrzaj());
                k2.setTextColor(Color.BLACK);
                k2.setTextSize(15);
                n.addView(k2);

                ocena=5;
                main.addView(n);
            }
        }



        LinearLayout n = new LinearLayout(getApplicationContext());
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(900,LayoutParams.MATCH_PARENT);
        np.setMargins(60,40,0,0);
        n.setLayoutParams(np);
        n.setBackgroundColor(Color.parseColor("#FFEF9D"));
        n.setOrientation(LinearLayout.VERTICAL);

        TextView k1 = new TextView(getApplicationContext());
        np=new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
        np.setMargins(20,10,0,0);
        k1.setLayoutParams(np);
        k1.setTypeface(boldTypeface);
        k1.setText("Dodajte komentar:");
        k1.setTextColor(Color.BLACK);
        k1.setTextSize(16);
        n.addView(k1);

        EditText kom = new EditText(getApplicationContext());
        np=new LinearLayout.LayoutParams(700,200);
        np.setMargins(20,10,0,10);
        kom.setLayoutParams(np);
        kom.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        kom.setBackgroundColor(Color.parseColor("#FFFFFF"));
        n.addView(kom);
        kom.setGravity(Gravity.TOP);
        komentar=kom;

        LinearLayout nn = new LinearLayout(getApplicationContext());
        LinearLayout.LayoutParams npp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
        npp.setMargins(0,0,0,0);
        nn.setLayoutParams(np);
        nn.setBackgroundColor(Color.parseColor("#FFEF9D"));
        nn.setOrientation(LinearLayout.HORIZONTAL);

        TextView ko = new TextView(getApplicationContext());
        ko.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
        ko.setTypeface(boldTypeface);
        ko.setText("Ocena: ");
        ko.setTextColor(Color.BLACK);
        ko.setTextSize(15);
        nn.addView(ko);

        zvezde.clear();
        for(int i=1;i<=5;i++){
            ImageView starfull = new ImageView(getApplicationContext());
            starfull.setImageResource(R.drawable.ic_star);
            starfull.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
            starfull.setOnClickListener(new NewClickListener(i));
            nn.addView(starfull);
            zvezde.add(starfull);
        }
        n.addView(nn);

        Button btn = new Button(getApplicationContext());
        np=new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
        np.setMargins(20,0,0,30);
        np.gravity= Gravity.TOP|Gravity.CENTER;
        np.weight = 2.0f;
        btn.setLayoutParams(np);
        btn.setText("Postavi komentar");
        btn.setBackgroundColor(Color.parseColor("#FFC95B"));
        btn.setTransformationMethod(null);
        btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(komentar.getText().toString().equals("")){
                    return;
                }

               Komentar.getKomentari().add(new Komentar(
                       Knjiga.getSelektovanaKnjiga().getId(),
                       Korisnik.getUlogovaniKorisnik().getKorime(),
                       ocena,
                       komentar.getText().toString()
               ));

                Intent intent = new Intent(DetaljiKnjige.this, DetaljiKnjige.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
            }
        });
        n.addView(btn);

        main.addView(n);
    }


    private String getPunoIme(String korime){
        for(Korisnik k:Korisnik.getKorisnici()){
            if(k.getKorime().equals(korime)) return "Korisnik: " + k.getIme() + " " + k.getPrezime() + " (" + k.getKorime() + ")";
        }
        return "Korisnik: Nije pronađen";
    }

    public void meni(View view){
        Intent intent = new Intent(this, Meni.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }

    public void preporuciKnjigu(View view) {
        Intent intent = new Intent(this, PreporuciKnjigu.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        this.finish();
    }
}

class NewClickListener implements View.OnClickListener
{
    int var;
    public NewClickListener(int var) {
        this.var = var;
    }

    @Override
    public void onClick(View v)
    {
       for(int i=0;i<=4;i++) {
           if(i<var) DetaljiKnjige.zvezde.get(i).setImageResource(R.drawable.ic_star);
           else DetaljiKnjige.zvezde.get(i).setImageResource(R.drawable.ic_star_empty);
       }
        DetaljiKnjige.ocena=var;
    }
}


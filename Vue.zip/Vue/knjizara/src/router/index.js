import Vue from 'vue';
import VueRouter from 'vue-router';
import Prijava from '../views/Prijava.vue';
import Registracija from '../views/Registracija.vue';
import Kupac from '../views/Kupac.vue';
import Prodavac from '../views/Prodavac.vue';
import KupacPromena1 from '../views/KupacPromena1.vue';
import KupacPromena2 from '../views/KupacPromena2.vue';
import ProdavacPromena1 from '../views/ProdavacPromena1.vue';
import ProdavacPromena2 from '../views/ProdavacPromena2.vue';
import KupacDetaljiKnjige from '../views/KupacDetaljiKnjige.vue';
import KupacPreporuciKnjigu from '../views/KupacPreporuciKnjigu.vue';
import KupacPreporuceneKnjige from '../views/KupacPreporuceneKnjige.vue';

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: Prijava
  },
  {
    path: '/prijava',
    component: Prijava
  },
  {
    path: '/registracija',
    component: Registracija
  },
  {
    path: '/kupac',
    component: Kupac
  },
  {
    path: '/prodavac',
    component: Prodavac
  },
  {
    path: '/kupac-promena1',
    component: KupacPromena1
  },
  {
    path: '/kupac-promena2',
    component: KupacPromena2
  },
  {
    path: '/prodavac-promena1',
    component: ProdavacPromena1
  },
  {
    path: '/prodavac-promena2',
    component: ProdavacPromena2
  },
  {
    path:'/detaljiknjige',
    component: KupacDetaljiKnjige
  },
  {
    path:'/preporuciknjigu',
    component: KupacPreporuciKnjigu
  },
  {
    path:'/preporuceneknjige',
    component: KupacPreporuceneKnjige
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router

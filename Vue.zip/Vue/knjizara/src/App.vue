<template>
  <div id="app">
    <router-view id="main"/>
  </div>
</template>

<style>
#app {
  font-family: 'Times New Roman', Times, serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
  color: #2c3e50;
  background-color:#fffee5;
  width: 100%;
  height: 100%;
}
#main{
  background-color:#fffee5;
  position:absolute;
  height: 100%;
  width: 100%;
}
.center {
  margin-left: auto;
  margin-right: auto;
}
.btn-app{
  background-color: #FFC95B !important;
  color:#2c3e50 !important;
  border: 0px !important;
}
@font-face{
font-family: 'League Script';
src: local("League Script"), url(./fonts/league-script.league-script.ttf) format("truetype");
}
#logo{
  background-color:#f3f4bb;
  height: 120px;
  width: 60%;
  display: inline-block;
}
#logo1{
margin-left: 60px;
float:left;
}
#logo2{
margin-left: 15px;
margin-top: 25px;
font-family: 'League Script';
font-size:72px;
float:left;
}
#navigation{
  font-size: 30px;
  font-style:italic;
  height: 120px;
  width: 40%;
  background-color:#f3f4bb;
  float:right;
  display: flex;
  align-items: center;
  text-align: center;
}
.menu{
width:100%;
min-height:47 px;
height:47px;
background-color:#FFEF9D;
margin-top:-7px;
display: inline-block;
}
</style>

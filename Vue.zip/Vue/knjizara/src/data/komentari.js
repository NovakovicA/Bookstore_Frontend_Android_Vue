let komentari=[
    {
    knjiga:0,
    korisnik:"pera",
    ocena:5,
    sadrzaj:"extra"
    },
    {
        knjiga:0,
        korisnik:"zika",
        ocena:3,
        sadrzaj:"nije lose"
    },
    {
        knjiga:0,
        korisnik:"vesna",
        ocena:1,
        sadrzaj:"ne sviđa mi se :("
    },    
    {
        knjiga:2,
        korisnik:"zika",
        ocena:5,
        sadrzaj:"dobra"
    },
    {
        knjiga:2,
        korisnik:"mika",
        ocena:4,
        sadrzaj:"super knjiga"
    }
];

export default komentari;
let preporuke=[
{
    od:"zika",
    za:"pera",
    knjiga:0,
    prikaz:1
},
{
    od:"zika",
    za:"pera",
    knjiga:4,
    prikaz:1
},
{
    od:"mika",
    za:"pera",
    knjiga:4,
    prikaz:1
},
{
    od:"vesna",
    za:"pera",
    knjiga:1,
    prikaz:1
},
{
    od:"vesna",
    za:"pera",
    knjiga:3,
    prikaz:1
}
];

export default preporuke;
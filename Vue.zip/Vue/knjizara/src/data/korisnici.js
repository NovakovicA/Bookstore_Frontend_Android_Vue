let korisnici = [
{
    ime:"Pera",
    prezime:"Perić",
    korime:"pera",
    lozinka:"123",
    brojTelefona:"0614325222",
    adresa:"Ustanička 11, Beograd",
    tip:0
},
{
    ime:"Žika",
    prezime:"Žikić",
    korime:"zika",
    lozinka:"123",
    brojTelefona:"062123467",
    adresa:"Gospodara Vučića 42, Beograd",
    tip:0
},
{
    ime:"Mika",
    prezime:"Mikić",
    korime:"mika",
    lozinka:"123",
    brojTelefona:"0654587920",
    adresa:"Guncate 50",
    tip:0
},
{
    ime:"Vesna",
    prezime:"Vesnić",
    korime:"vesna",
    lozinka:"123",
    brojTelefona:"0641232929",
    adresa:"Nova Ulica 10, Mars",
    tip:0
},
{
    ime:"Mitar",
    prezime:"Mitrić",
    korime:"mitar",
    lozinka:"123",
    brojTelefona:"065123129",
    adresa:"Pilota Mihajla Petrovića 13, Beograd",
    tip:0
},
{
    ime:"Marko",
    prezime:"Marković",
    korime:"marko",
    lozinka:"123",
    brojTelefona:"0612328828",
    adresa:"Ustanička 13, Beograd",
    tip:1
}
];

export default korisnici;
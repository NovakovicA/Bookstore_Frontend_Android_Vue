let predef_slike=[
{
   slika:"1.jpg"
},
{
    slika:"2.jpg"
},
{
    slika:"3.jpg"
},
{
    slika:"4.jpg"
},
];

export default predef_slike;
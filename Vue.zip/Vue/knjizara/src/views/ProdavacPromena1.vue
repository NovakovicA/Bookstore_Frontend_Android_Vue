<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>

<div id="navigation">

<div id="naziv">{{naziv}}</div>
 <router-link to="/kupac#" id="odjava" @click.native="odjava">Odjava</router-link>
</div>

<div class="menu">
<button type="button" class="btn btn-app" style="margin-top:6px;margin-left:10px; margin-right:10px;" v-on:click="glavna()">Povratak na glavnu stranicu</button>
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px; margin-right:10px;" v-on:click="prodavacpromena2()">Promena korisničkog imena/lozinke</button> 
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px;" v-on:click="prodavacpromena1()">Promena podataka</button>
</div>

<br><br><br><br><br>
  <table class="center">
    <tr>
    <td style="font-size:20px;">Ime:</td>
    <td><input type="text" id="usr" size="25" v-model="ime"></td>
    </tr>

    <tr>
    <td style="font-size:20px;">Prezime:</td>
    <td><input type="text" id="usr" size="25" v-model="prezime"></td>
    </tr>

    <tr>
    <td style="font-size:20px;">Broj telefona:</td>
    <td><input type="text" id="usr" size="25" v-model="brTel"></td>
    </tr>

      <tr>
    <td style="font-size:20px;">Adresa:</td>
    <td><input type="text" id="usr" size="35" v-model="adresa"></td>
    </tr>

    <tr> <td colspan="2" style="text-align: center;"><button type="button" class="btn btn-success" v-on:click="promeniPodatke()">Promeni podatke</button></td></tr>
  </table>

<br><br>
<div v-if="greska" class="greskaProzor"> 
  <div class="greskaProzorZatvori" v-on:click="greska=false"> <x-circle-icon size="1.3x"></x-circle-icon>&nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;{{greska_poruka}}
</div>

<div v-if="uspesno" class="uspesnoProzor"> 
  <div class="uspesnoProzorZatvori" v-on:click="uspesno=false"> <x-circle-icon size="1.3x"></x-circle-icon>&nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;{{uspesno_poruka}}
</div>

</div>

</template>


<style scoped>
#naziv{
width:100%; 
margin-top: 50px;
font-size:30px;
}
#odjava{
margin-top: 50px;
margin-right:100px;
font-size:20px;
font-weight: bold;
color: #2c3e50;  
text-decoration: underline; 
text-align:right;
}
td{
  padding: 5px;
}
.greskaProzor{
  text-align: justify;
  background-color: #fa9999;
  height: 10%;
  width: 30%;
  margin-left:30%;
}
.greskaProzorZatvori,.uspesnoProzorZatvori {
  cursor: default;
  font-weight: bold;
  text-align: right;
}
.uspesnoProzor{
  text-align: justify;
  background-color: #0ac438;
  height: 10%;
  width: 40%;
  margin-left:30%;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import { XCircleIcon } from 'vue-feather-icons';

export default {
  name: "ProdavacPromena1",
  components: {
    XCircleIcon
  },
    data(){
      return{
      naziv:"",
      greska: false,
      greska_poruka: "",
      ime:"",
      prezime:"",
      brTel:"",
      adresa: "",
      uspesno: false,
      uspesno_poruka: ""
      }
  },
  methods:{
    odjava: function(){
      localStorage.clear("korisnik");
      this.$router.push("prijava");
    },
    prodavacpromena1: function(){
      this.$router.push('prodavac-promena1');
    },
     glavna: function(){
      this.$router.push('prodavac');
    },
    prodavacpromena2: function(){
      this.$router.push('prodavac-promena2');
    },

    promeniPodatke:function (){
      this.brTel = this.brTel.replace(' ','');
      this.brTel = this.brTel.replace('-','');

    if (isNaN(this.brTel)){
      this.greska_poruka="Neispravan format broja telefona.";
      this.greska=true;
    }
    else if(this.ime == "" || this.prezime== "" || this.brTel== "" || this.adresa== ""){
      this.greska_poruka="Sva polja moraju biti popunjena.";
      this.greska=true;
    }
    else{
      let korime=localStorage.getItem("korisnik");
      let korisnik = korisnici.find(kor=> kor.korime==korime);

      korisnik.ime=this.ime;
      korisnik.prezime=this.prezime;
      korisnik.brojTelefona=this.brTel;
      korisnik.adresa=this.adresa;
      this.uspesno_poruka="Podaci uspešno promenjeni.";
      this.greska=false;
      this.uspesno=true;
    }
    }
},
    mounted() {   
    document.title = "Knjižara Perce - Promena podataka"; 
    let korime=localStorage.getItem("korisnik");
    if(korime===null) this.$router.push("prijava");
    else{
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      if(korisnik.tip!=1) this.$router.push("prodavac");
      this.naziv=korisnik.ime + " " + korisnik.prezime;
      this.naziv+=", prodavac";

      this.ime = korisnik.ime;
      this.prezime = korisnik.prezime;
      this.brTel = korisnik.brojTelefona;
      this.adresa = korisnik.adresa;
    }
  }
}
</script>

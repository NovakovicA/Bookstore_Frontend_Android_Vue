<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>

<div id="navigation">

<div id="naziv">{{naziv}}</div>
 <router-link to="/kupac#" id="odjava" @click.native="odjava">Odjava</router-link>
</div>

<div class="menu">
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;" v-on:click="knjige()">Pregled knjiga <book-icon size="1.7x" class="custom-class"></book-icon></button>
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;" v-on:click="preporuceneknjige()">Preporučene knjige <bell-icon size="1.5x" class="custom-class"></bell-icon></button>
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px; margin-right:10px;" v-on:click="kupacpromena2()">Promena korisničkog imena/lozinke</button> 
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px;" v-on:click="kupacpromena1()">Promena podataka</button>
</div>


<br><br>
<div class="baner">Preporučene knjige:</div>
<br>
<div>
  <div class="row" style="width:100%; background-color:#fffee5;margin-left:0px;margin-bottom:0px;" v-for="i in Math.ceil(preporuke.length / 3)" v-bind:key="`B${i}`">
    <div class="col-3" style="background-color:#FFEF9D; position:relative; word-wrap: break-word; margin-left:10px; margin-right:10px; margin-top:20px;" v-for="(preporuka, index) in  preporuke.slice((i - 1) * 3, i * 3)" v-bind:key="`P${index}`">
          <x-icon size="1.5x" class="custom-class" style="color:red; position:absolute; top:0px; right:0px;" v-on:click="sakrijPreporuku(preporuka)"></x-icon>
          <div style="display: inline-block"><img v-bind:src="'/img/' + dohvatiKnjigu(preporuka.knjiga).slika" width="140px" height="220px" style="margin-top:-30px; margin-left:-5px; vertical-align: top;" v-on:click="detaljiKnjige(preporuka.knjiga)"></div>
          <div style="display: inline-block; margin-left:10px;">
          <p style="font-weight: bold;">{{dohvatiKnjigu(preporuka.knjiga).naziv}}</p>
          <p style="font-style: italic;">{{dohvatiKnjigu(preporuka.knjiga).autori}}</p>

          <p style="position: absolute; bottom:20px;" v-if="dohvatiKnjigu(preporuka.knjiga).promocija==true">
            <span style="text-decoration: line-through;">{{dohvatiKnjigu(preporuka.knjiga).cena}}</span>
          &nbsp;
            <span style="font-weight:bold; color:red;">{{dohvatiKnjigu(preporuka.knjiga).promotivna_cena}} din.</span>
          </p>

          <p style="position: absolute; bottom:20px;" v-if="dohvatiKnjigu(preporuka.knjiga).promocija==false">
            <span style="font-weight:bold;">{{dohvatiKnjigu(preporuka.knjiga).cena}} din.</span>
          </p>
          </div>
          <p style="font-weight:bold;"> Preporučeno od {{dohvatiPunoIme(preporuka.od)}}</p>
    </div>
    </div>
</div>


</div>
</template>


<style scoped>
#naziv{
width:100%; 
margin-top: 50px;
font-size:30px;
}
#odjava{
margin-top: 50px;
margin-right:100px;
font-size:20px;
font-weight: bold;
color: #2c3e50;  
text-decoration: underline; 
text-align:right;
}
td{
  padding: 5px;
}
.baner{
  font-style: oblique;
  font-weight: bold;
  font-size:25px;
  text-decoration: underline;
  text-align: center;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import { BookIcon } from 'vue-feather-icons';
import { BellIcon } from 'vue-feather-icons';
import preporuke from "../data/preporuke.js";
import knjige from "../data/knjige.js";
import { XIcon } from 'vue-feather-icons';

export default {
  name: "KupacPreporuceneKnjige",
  components: {
    BookIcon,
    BellIcon, 
    XIcon
  },
    data(){
      return{
      naziv:"",
      preporuke:[]
    }
  },
  methods:{
    odjava: function(){
      localStorage.clear("korisnik");
      this.$router.push("prijava");
    },
    kupacpromena1: function(){
      this.$router.push('kupac-promena1');
    },
     knjige: function(){
      this.$router.push('kupac');
    },
    kupacpromena2: function(){
      this.$router.push('kupac-promena2');
    },
    preporuceneknjige: function(){
      this.$router.push('preporuceneknjige');
    },
    dohvatiPunoIme: function(korime){
      let korisnik = korisnici.find(k=>k.korime==korime);
      return korisnik.ime + " " + korisnik.prezime + " (" + korime + ")";
     },
    detaljiKnjige: function(id){
      localStorage.setItem("knjiga_id",id);
      this.$router.push("/detaljiknjige");
    },
    dohvatiPreporuke: function(){
      this.preporuke.splice(0);
      preporuke.forEach(p=>{
        if(p.za==localStorage.getItem("korisnik") && p.prikaz==1) this.preporuke.push(p);
      });
    },
    dohvatiKnjigu: function(id){
      return knjige.find(k=>k.id==id);
    },
    sakrijPreporuku: function(prep){
      prep.prikaz=0;
      this.dohvatiPreporuke();
    }
    },
    mounted() {   
    document.title = "Knjižara Perce - Preporučene knjige"; 
    let korime=localStorage.getItem("korisnik");
    if(korime===null) this.$router.push("prijava");
    else{
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      if(korisnik.tip!=0) this.$router.push("prodavac");
      this.naziv=korisnik.ime + " " + korisnik.prezime;
      this.naziv+=", kupac";
      this.dohvatiPreporuke();
    }
  }
}
</script>

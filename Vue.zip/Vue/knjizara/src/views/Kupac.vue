<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>

<div id="navigation">

<div id="naziv">{{naziv}}</div>
 <router-link to="/kupac#" id="odjava" @click.native="odjava">Odjava</router-link>
</div>

<div class="menu">
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;">Pregled knjiga <book-icon size="1.7x" class="custom-class" v-on:click="knjige()"></book-icon></button>
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;" v-on:click="preporuceneknjige">Preporučene knjige <bell-icon size="1.5x" class="custom-class"></bell-icon></button>
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px; margin-right:10px;" v-on:click="kupacpromena2()">Promena korisničkog imena/lozinke</button> 
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px;" v-on:click="kupacpromena1()">Promena podataka</button>
</div>


<div class="row red">
  <div class="baner">Promocije</div>
<div class="col-1" style="margin-left:50px;margin-top: 70px;" >
    <chevron-left-icon size="1.5x" v-on:click="minus1()" v-if="pozicija1>0"></chevron-left-icon>
    <chevron-left-icon size="1.5x" style="color:gray;" v-if="pozicija1<=0"></chevron-left-icon>
</div>

<div class="col-3" style="background-color:#FFFEE5; margin-top: -20px; max-height:240px; position:relative; border:1px solid red; word-wrap: break-word;" v-for="num in kartice" v-bind:key="num" v-bind:style="num==2?'margin-right:50px;':'margin-right:10px;'" v-on:click="detaljiKnjige(promocije[pozicija1+num].id)" >
    <div v-if="pozicija1+num <= promocije.length-1">
    <div style="display: inline-block"><img v-bind:src="'/img/' + promocije[pozicija1+num].slika" width="140px" height="220px" style="margin-top:-30px; margin-left:-5px; vertical-align: top;"></div>
    <div style="display: inline-block; margin-left:10px;">
    <p style="font-weight: bold;">{{promocije[pozicija1+num].naziv}}</p>
    <p style="font-style: italic;">{{promocije[pozicija1+num].autori}}</p>
    <p style="position: absolute; bottom:0;">
      <span style="text-decoration: line-through;">{{promocije[pozicija1+num].cena}}</span>
    &nbsp;
      <span style="font-weight:bold; color:red;">{{promocije[pozicija1+num].promotivna_cena}} din.</span>
    </p>
    </div>
    </div>
</div>

<div class="col-1" style="margin-top: 70px;">
    <chevron-right-icon size="1.5x" v-on:click="plus1()"  v-if="pozicija1<maxPromocija()-3"></chevron-right-icon> 
    <chevron-right-icon size="1.5x" style="color:gray;" v-if="pozicija1>=maxPromocija()-3"></chevron-right-icon> 
</div>
</div>





<div class="row red">
  <div class="baner">Dostupne knjige</div>
<div class="col-1" style="margin-left:50px;margin-top: 70px;">
    <chevron-left-icon size="1.5x" v-on:click="minus2()" v-if="pozicija2>0"></chevron-left-icon>
    <chevron-left-icon size="1.5x" style="color:gray;" v-if="pozicija2<=0"></chevron-left-icon>
</div>

<div class="col-3" style="background-color:#FFFEE5; margin-top: -20px; max-height:240px; position:relative; word-wrap: break-word;" v-for="num in kartice" v-bind:key="num" v-bind:style="num==2?'margin-right:50px;':'margin-right:10px;'" v-on:click="detaljiKnjige(dostupne[pozicija2+num].id)">
    <div v-if="pozicija2+num <= dostupne.length-1">
    <div style="display: inline-block"><img v-bind:src="'/img/' + dostupne[pozicija2+num].slika" width="140px" height="220px" style="margin-top:-30px; margin-left:-5px; vertical-align: top;"></div>
    <div style="display: inline-block; margin-left:10px;">
    <p style="font-weight: bold;">{{dostupne[pozicija2+num].naziv}}</p>
    <p style="font-style: italic;">{{dostupne[pozicija2+num].autori}}</p>
    <p style="position: absolute; bottom:0;">
      <span style="font-weight:bold;">&nbsp; &nbsp;{{dostupne[pozicija2+num].cena}} din.</span>
    </p>
    </div>
    </div>
</div>

<div class="col-1" style="margin-top: 70px;">
    <chevron-right-icon size="1.5x" v-on:click="plus2()"  v-if="pozicija2<maxDostupne()-3"></chevron-right-icon> 
    <chevron-right-icon size="1.5x" style="color:gray;" v-if="pozicija2>=maxDostupne()-3"></chevron-right-icon> 
</div>
</div>

</div>
</template>


<style scoped>
#naziv{
width:100%; 
margin-top: 50px;
font-size:30px;
}
#odjava{
margin-top: 50px;
margin-right:100px;
font-size:20px;
font-weight: bold;
color: #2c3e50;  
text-decoration: underline; 
text-align:right;
}
td{
  padding: 5px;
}
.red{
width:99%; 
background-color:#FFEF9D;
margin-top:10px;
margin-left:5px;
height:37%;
}
.baner{
  font-style: oblique;
  font-weight: bold;
  font-size:20px;
  text-decoration: underline;
  text-align: center;
  margin-top:-5px;
  margin-bottom: 0px;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import { BookIcon } from 'vue-feather-icons';
import { BellIcon } from 'vue-feather-icons';
import { ChevronLeftIcon, ChevronRightIcon } from 'vue-feather-icons';
import knjige from "../data/knjige.js";

export default {
  name: "Kupac",
  components: {
    BookIcon,
    BellIcon,
    ChevronLeftIcon,
    ChevronRightIcon
  },
    data(){
      return{
        naziv:"",
        pozicija1:0,
        pozicija2:0,
        kartice:[0,1,2],
        dostupne:[],
        promocije:[]
      }
  },
  methods:{
    odjava: function(){
      localStorage.clear("korisnik");
      this.$router.push("prijava");
    },
    knjige: function(){
      this.$router.push('kupac');
    },
    kupacpromena1: function(){
      this.$router.push('kupac-promena1');
    },
    kupacpromena2: function(){
      this.$router.push('kupac-promena2');
    },
    preporuceneknjige: function(){
      this.$router.push('preporuceneknjige');
    },

    plus1: function(){
      this.pozicija1++;
      this.promocije.splice(0);
       knjige.forEach(k => {
        if(k.promocija==true) this.promocije.push(k);
      });
    },
    plus2: function(){
      this.pozicija2++;
      this.dostupne.splice(0);
       knjige.forEach(k => {
        if(k.promocija==false) this.dostupne.push(k);
      });
    },
    minus1: function(){
      this.pozicija1--;
      this.promocije.splice(0);
       knjige.forEach(k => {
        if(k.promocija==true) this.promocije.push(k);
      });
    },
    minus2: function(){
      this.pozicija2--;
      this.dostupne.splice(0);
      knjige.forEach(k => {
        if(k.promocija==false) this.dostupne.push(k);
      });
    },

    maxPromocija: function(){
      let p=0;
      knjige.forEach(k => {
        if(k.promocija==true) p++;
      });
      return p;
    },
    maxDostupne: function(){
      let p=0;
      knjige.forEach(k => {
        if(k.promocija==false) p++;
      });
      return p;
    },
    detaljiKnjige: function(id){
      localStorage.setItem("knjiga_id",id);
      this.$router.push("/detaljiknjige");
    }
},
    mounted() {   
    document.title = "Knjižara Perce - Knjige"; 
    let korime=localStorage.getItem("korisnik");
    if(korime===null) this.$router.push("prijava");
    else{
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      if(korisnik.tip!=0) this.$router.push("prodavac");
      this.naziv=korisnik.ime + " " + korisnik.prezime;
      this.naziv+=", kupac";

      this.promocije.splice(0);
       knjige.forEach(k => {
        if(k.promocija==true) this.promocije.push(k);
      });

      this.dostupne.splice(0);
      knjige.forEach(k => {
        if(k.promocija==false) this.dostupne.push(k);
      });
    }
  }
}
</script>

<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>

<div id="navigation">

<div id="naziv">{{naziv}}</div>
 <router-link to="/kupac#" id="odjava" @click.native="odjava">Odjava</router-link>
</div>

<div class="menu">
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;" v-on:click="knjige()">Pregled knjiga <book-icon size="1.7x" class="custom-class"></book-icon></button>
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;" v-on:click="preporuceneknjige()">Preporučene knjige <bell-icon size="1.5x" class="custom-class"></bell-icon></button>
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px; margin-right:10px;" v-on:click="kupacpromena2()">Promena korisničkog imena/lozinke</button> 
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px;" v-on:click="kupacpromena1()">Promena podataka</button>
</div>

<br><br><br>
<div class="row" style="width:100%; position:relative; margin-left:0px; margin-right:0px;">
<div class="col-3" style="background-color:#FFEF9D; margin-top: -20px; max-height:240px; position:relative; word-wrap: break-word; margin-left:30px;" v-on:click="detaljiKnjige(knjiga.id)">
    <div style="display: inline-block"><img v-bind:src="'/img/' + knjiga.slika" width="140px" height="220px" style="margin-top:-30px; margin-left:-5px; vertical-align: top;"></div>
    <div style="display: inline-block; margin-left:10px;">
    <p style="font-weight: bold;">{{knjiga.naziv}}</p>
    <p style="font-style: italic;">{{knjiga.autori}}</p>
    <p style="position: absolute; bottom:0;" v-if="knjiga.promocija==true">
      <span style="text-decoration: line-through;">{{knjiga.cena}}</span>
    &nbsp;
      <span style="font-weight:bold; color:red;">{{knjiga.promotivna_cena}} din.</span>
    </p>
    <p style="position: absolute; bottom:0;" v-if="knjiga.promocija==false">
      <span style="font-weight:bold;">{{knjiga.cena}} din.</span>
    </p>
    </div>
</div>
<div class="col-3" style="background-color:#FFEF9D; margin-top: -20px; max-height:240px; position:relative; word-wrap: break-word; margin-left:30px;">
<span v-for="(korisnik,index) in korisnici" v-bind:key="`${index}`" style="font-weight:bold;">
<user-check-icon size="1.5x" class="custom-class" v-if="proveriPostojanjePreporuke(korisnik.korime)==true" v-on:click="izbrisiPreporuku(korisnik.korime)" style="margin-right:20px;"></user-check-icon>
<user-x-icon size="1.5x" class="custom-class" v-if="proveriPostojanjePreporuke(korisnik.korime)==false" v-on:click="napraviPreporuku(korisnik.korime)" style="margin-right:20px;"></user-x-icon>

{{dohvatiPunoIme(korisnik.korime)}}
<br><br>
</span>
</div>
</div>

</div>
</template>


<style scoped>
#naziv{
width:100%; 
margin-top: 50px;
font-size:30px;
}
#odjava{
margin-top: 50px;
margin-right:100px;
font-size:20px;
font-weight: bold;
color: #2c3e50;  
text-decoration: underline; 
text-align:right;
}
td{
  padding: 5px;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import { BookIcon } from 'vue-feather-icons';
import { BellIcon } from 'vue-feather-icons';
import { UserCheckIcon, UserXIcon } from 'vue-feather-icons';
import knjige from "../data/knjige.js";
import preporuke from "../data/preporuke.js";

export default {
  name: "KupacPreporuciKnjigu",
  components: {
    BookIcon,
    BellIcon, 
    UserXIcon,
    UserCheckIcon,
  },
    data(){
      return{
      naziv:"",
      knjiga:{
        id:-1,
        naziv:"",
        autori:"",
        cena:0,
        promocija:false,
        promotivna_cena:0,
        broj_strana:0,
        godina_izdanja:0,
        opis:"",
        slika:""
    },
    korisnici:[],
    preporuke:[]
    }
  },
  methods:{
    odjava: function(){
      localStorage.clear("korisnik");
      this.$router.push("prijava");
    },
    kupacpromena1: function(){
      this.$router.push('kupac-promena1');
    },
     knjige: function(){
      this.$router.push('kupac');
    },
    kupacpromena2: function(){
      this.$router.push('kupac-promena2');
    },
    dohvatiPunoIme: function(korime){
      let korisnik = korisnici.find(k=>k.korime==korime);
      return korisnik.ime + " " + korisnik.prezime + " (" + korime + ")";
     },
    detaljiKnjige: function(id){
      localStorage.setItem("knjiga_id",id);
      this.$router.push("/detaljiknjige");
    },
    dohvatiKorisnike: function(){
      this.korisnici.splice(0);
      korisnici.forEach(k=>{
        if(k.korime!=localStorage.getItem("korisnik") && k.tip==0) this.korisnici.push(k);
      });
    },
    dohvatiPreporuke: function(){
      this.preporuke.splice(0);
      preporuke.forEach(k=>{
        if(k.knjiga==localStorage.getItem("knjiga_id") && k.od==localStorage.getItem("korisnik")) this.preporuke.push(k);
      });
    },
    proveriPostojanjePreporuke: function(korime){
      let ret=false;
      this.preporuke.forEach(k=>{
        if(k.za == korime) ret=true;
      });
      return ret;
    },
    napraviPreporuku: function(korime){
      let nova_preporuka={
        od:localStorage.getItem("korisnik"),
        za:korime,
        knjiga:localStorage.getItem("knjiga_id"),
        prikaz:1
      };
      preporuke.push(nova_preporuka);
      this.dohvatiKorisnike();
      this.dohvatiPreporuke();
    },
    izbrisiPreporuku: function(korime){
      let ind = preporuke.findIndex((p)=>{
        return (p.od==localStorage.getItem("korisnik") &&  p.knjiga==localStorage.getItem("knjiga_id") && p.za==korime);
      });
      preporuke.splice(ind,1);
      this.dohvatiKorisnike();
      this.dohvatiPreporuke();
    },
    preporuceneknjige: function(){
      this.$router.push('preporuceneknjige');
    },
    },
    mounted() {   
    document.title = "Knjižara Perce - Preporuči knjigu"; 
    let korime=localStorage.getItem("korisnik");
    if(korime===null) this.$router.push("prijava");
    else{
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      if(korisnik.tip!=0) this.$router.push("prodavac");
      this.naziv=korisnik.ime + " " + korisnik.prezime;
      this.naziv+=", kupac";
      this.knjiga = knjige.find(knjiga => knjiga.id==localStorage.getItem("knjiga_id"));
      if (this.knjiga===undefined || this.knjiga===null) this.$router.push("/kupac");
      this.dohvatiKorisnike();
      this.dohvatiPreporuke();
    }
  }
}
</script>

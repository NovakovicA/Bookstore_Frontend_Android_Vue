<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>
<div id="navigation">
  <div id="prijava"> Prijava </div>
 <router-link to="/registracija" id="registracija">Registracija</router-link>
</div>

<br><br><br><br><br>
  <table class="center">
    <tr>
    <td style="font-size:20px;">Korisničko ime:</td>
    <td><input type="text" id="usr" size="25" v-model="korime"></td>
    </tr>
    <tr>
      <td style="font-size:20px;"> Lozinka: </td>
      <td> <input type="password" id="pwd" size="25" v-model="lozinka"></td>
    </tr>
    <tr> <td colspan="2" style="text-align: center;"><button type="button" class="btn btn-success" v-on:click="prijava(korime,lozinka)">Prijava</button></td></tr>
  </table>

<br><br>
<div v-if="greska" class="greskaProzor"> 
  <div class="greskaProzorZatvori" v-on:click="greska=false"> <x-circle-icon size="1.3x"></x-circle-icon> &nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;{{greska_poruka}}
</div>

<div v-if="uspesno" class="uspesnoProzor"> 
  <div class="uspesnoProzorZatvori" v-on:click="uspesno=false"> <x-circle-icon size="1.3x"></x-circle-icon> &nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;{{uspesno_poruka}}
</div>

</div>

</template>

<style scoped>
#prijava{
margin-top: 50px;
margin-left:50px;
font-weight:bold;
color: #2c3e50;
}
#registracija{
margin-top: 50px;
margin-left:80px;
font-weight: normal;
color: #2c3e50;  
text-decoration: underline; 
}
td{
  padding: 5px;
}
.greskaProzor{
  text-align: justify;
  background-color: #fa9999;
  height: 10%;
  width: 20%;
  margin-left:40%;
}
.greskaProzorZatvori,.uspesnoProzorZatvori {
  cursor: default;
  font-weight: bold;
  text-align: right;
}
.uspesnoProzor{
  text-align: justify;
  background-color: #0ac438;
  height: 10%;
  width: 40%;
  margin-left:30%;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import { XCircleIcon } from 'vue-feather-icons';

export default {
  name: "Prijava",
  components: {
    XCircleIcon
  },
  mounted() {  
    document.title = "Knjižara Perce - Prijava"; 
    let korime=localStorage.getItem("korisnik");
    if(korime!==null) {
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      if(korisnik.tip==0) this.$router.push("kupac");
      else if(korisnik.tip==1) this.$router.push("prodavac");
    }
  },
  data(){
    return{
      korime:"",
      lozinka:"",
      greska: false,
      greska_poruka: "",
      uspesno: false,
      uspesno_poruka: ""
    }
  },
  methods:{
    prijava(korime,lozinka){
    let korisnik = korisnici.find(kor=> kor.korime==korime && kor.lozinka==lozinka);
    if(korisnik===undefined){
      this.greska_poruka="Pogrešno korisničko ime ili lozinka.";
      this.greska=true;
      this.uspesno-false;
    }
    else{
      this.uspesno_poruka="Prijava uspešno obavljena, prebacivanje na stranicu korisnika...";
      this.greska=false;
      this.uspesno=true;
      localStorage.setItem("korisnik",korime);
      if(korisnik.tip==0) setTimeout(() => this.$router.push("kupac"), 3000);
      else if(korisnik.tip==1) setTimeout(() => this.$router.push("prodavac"), 3000);
    }
  }
}
}
</script>

<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>

<div id="navigation">

<div id="naziv">{{naziv}}</div>
 <router-link to="/prodavac#" id="odjava" @click.native="odjava">Odjava</router-link>
</div>

<div class="menu">
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px; margin-right:10px;" v-on:click="prodavacpromena2()">Promena korisničkog imena/lozinke</button> 
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px;" v-on:click="prodavacpromena1()">Promena podataka</button>
</div>

<div class="row" style="margin-left:0px; margin-right:0px; width=100%; background-color:#FFEF9D; height:38%;">
  <div class="col-3" style="margin-bottom:20px;"> 
      <div class="baner" style="margin-left:50px;">Pretraga knjiga:</div>
      <div style="margin-left:10px;">
            <table>
              <tr>
              <td style="font-size:20px;">Naslov:</td>
              <td><input type="text" size="20" v-model="naslov"></td>
              </tr>
              <tr>
                <td style="font-size:20px;">Autor:</td>
                <td> <input type="text" size="20" v-model="autor"></td>
              </tr>
              <tr> <td colspan="2" style="text-align: right;"><button type="button" class="btn btn-app" v-on:click="pretrazi()">Pretraži</button></td></tr>
            </table>
      </div>
</div>

          <div class="col-3" style="background-color:#FFFEE5; position:relative; word-wrap: break-word; margin-left:10px; margin-right:10px; margin-top:20px; margin-bottom:10px; " v-if="knjiga!==undefined">
          <div style="display: inline-block"><img v-bind:src="'/img/' + knjiga.slika" width="140px" height="220px" style="margin-top:-30px; margin-left:-5px; vertical-align: top; margin-bottom:10px;"></div>
          <div style="display: inline-block; margin-left:10px;">
          <p style="font-weight: bold;">{{knjiga.naziv}}</p>
          <p style="font-style: italic;">{{knjiga.autori}}</p>

          <p style="position: absolute; bottom:20px;" v-if="knjiga.promocija==true">
            <span style="text-decoration: line-through;">{{knjiga.cena}}</span>
          &nbsp;
            <span style="font-weight:bold; color:red;">{{knjiga.promotivna_cena}} din.</span>
          </p>

          <p style="position: absolute; bottom:20px;" v-if="knjiga.promocija==false">
            <span style="font-weight:bold;">{{knjiga.cena}} din.</span>
          </p>
          </div>
  </div>
  <div class="col-4" style="background-color:#FFEF9D; position:relative;" v-if="knjiga!==undefined">
    <button class="btn btn-app" v-if="knjiga.promocija==true" style="position:absolute; bottom:20px; left:200px;" v-on:click="ukiniPromociju()">Ukini promociju za knjigu</button>
    
    <div v-if="knjiga.promocija==false">
      <span style="position:absolute; top:20px; left:200px;"> <label for="promo" style="margin-right:15px;">Promotivna cena:</label><input type="text" v-model="promotivna_cena" size="10" id="promo" style="text-align:right;"></span>
      <button class="btn btn-app" style="position:absolute; bottom:20px; left:200px;" v-on:click="dodajPromociju()">Postavi promociju za knjigu</button>
    </div>
  </div>
</div>

<div class="row" style="margin-left:0px; margin-right:0px; width=100%; background-color:#FFEF9D; margin-top:10px;">
      <div class="col-3"> 
        <div class="baner" style="margin-left:50px;">Dodavanje knjige:</div>
        <table>
        <tr>
          <td>Naslov:</td>
          <td><input type="text"  size="30" v-model="d_naslov"></td>
        </tr>
      <tr>
          <td>Autori:</td>
          <td><input type="text" size="30" v-model="d_autori"></td>
        </tr>
        <tr>
          <td>Opis:</td>
          <td><textarea rows="5" cols="27" style="resize: none;" v-model="d_opis"></textarea></td>
        </tr>
      </table>
      </div>

      <div class="col-3"> 
        <br>
        <table>
        <tr>
          <td>Godina izdanja:</td>
          <td><input type="text"  size="30" v-model="d_god"></td>
        </tr>
      <tr>
          <td>Broj strana:</td>
          <td><input type="text" size="30" v-model="d_brstr"></td>
        </tr>
        <tr>
          <td>Cena:</td>
          <td><input type="text" size="30" v-model="d_cena"></td>
        </tr>
      </table>
      <br>
      <br>
      <br>
      <button class="btn btn-app" style="margin-right: 30px; margin-left:110px;" v-on:click="izaberiSliku()">Izaberi sliku</button>
      <button class="btn btn-app" style="border: 1px solid black !important;" v-on:click="dodajKnjigu()">Dodaj knjigu</button>
      </div>

      <div class="col-6" style="position:relative;"> 
        <div v-if="greska" class="greskaProzor"> 
          <div class="greskaProzorZatvori" v-on:click="greska=false"> <x-circle-icon size="1.3x"></x-circle-icon> &nbsp;</div>
        &nbsp;&nbsp;&nbsp;&nbsp;{{greska_poruka}}
        </div>

        <div v-if="uspesno" class="uspesnoProzor"> 
          <div class="uspesnoProzorZatvori" v-on:click="uspesno=false"> <x-circle-icon size="1.3x"></x-circle-icon> &nbsp;</div>
        &nbsp;&nbsp;&nbsp;&nbsp;{{uspesno_poruka}}
        </div>
      </div>
</div>

<modal name="izaberisliku">
  <span v-for="(slika,index) in predef_slike" v-bind:key="`SL${index}`">
    <img v-bind:src="'/img/' + slika.slika" width="80px" height="140px" style="margin-top:10px; margin-bottom:10px; margin-right: 10px; margin-left:10px;" v-on:click="postaviSliku(slika.slika)"> 
  </span>
</modal>

</div>
</template>


<style scoped>
#naziv{
width:100%; 
margin-top: 50px;
font-size:30px;
}
#odjava{
margin-top: 50px;
margin-right:100px;
font-size:20px;
font-weight: bold;
color: #2c3e50;  
text-decoration: underline; 
text-align:right;
}
td{
  padding: 5px;
}
.baner{
  font-style: oblique;
  font-weight: bold;
  font-size:20px;
  text-decoration: underline;
  text-align: left;
}
.greskaProzor{
  text-align: justify;
  background-color: #fa9999;
  margin-left:40%;
  margin-top:20px;
}
.greskaProzorZatvori,.uspesnoProzorZatvori {
  cursor: default;
  font-weight: bold;
  text-align: right;
}
.uspesnoProzor{
  text-align: justify;
  background-color: #0ac438;
  margin-left:30%;
  margin-top:20px;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import knjige from "../data/knjige.js";
import { XCircleIcon } from 'vue-feather-icons';
import predef_slike from "../data/predef_slike";

export default {
  name: "Prodavac",
  components: {
    XCircleIcon
  },
    data(){
      return{
        naziv:"",
        naslov:"",
        autor:"",
        knjiga:undefined,
        promotivna_cena:"",
        greska: false,
        greska_poruka: "",
        uspesno: false,
        uspesno_poruka: "",

        d_naslov:"",
        d_autori:"",
        d_opis:"",
        d_god:"",
        d_brstr:"",
        d_cena:"",
        d_slika:"",
        predef_slike
      }
  },
  methods:{
    odjava: function(){
      localStorage.clear("korisnik");
      this.$router.push("prijava");
    },
    prodavacpromena1:function(){
      this.$router.push('prodavac-promena1');
    },
    prodavacpromena2:function(){
      this.$router.push('prodavac-promena1');
    },
    pretrazi: function(){
      let found=false;
      for(let k of knjige){
        if (this.naslov!="" && this.autor=="") {if (k.naziv.toLowerCase().indexOf(this.naslov.toLowerCase())!=-1) {
          this.knjiga=k;
          found=true;
          break;
        }}
        if (this.naslov=="" && this.autor!="") {if (k.autori.toLowerCase().indexOf(this.autor.toLowerCase())!=-1) {
          this.knjiga=k;
          found=true;
          break;
        }}
        if (this.naslov!="" && this.autor!="") {if (k.autori.toLowerCase().indexOf(this.autor.toLowerCase())!=-1 && k.naziv.toLowerCase().indexOf(this.naslov.toLowerCase())!=-1) {
          this.knjiga=k;
          found=true;
          break;
        }}
      }
      if(!found) this.knjiga=undefined;
    },
    ukiniPromociju: function(){
      this.knjiga.promocija=false;
      this.knjiga.promotivna_cena=0;
      this.uspesno_poruka="Uspešno uklonjena promocija knjige.";
      this.uspesno=true;
      this.greska=false;
    },
    dodajPromociju: function(){
      if(isNaN(this.promotivna_cena)==true){
        this.greska_poruka="Promotivna cena mora biti broj.";
        this.uspesno=false;
        this.greska=true;
        return;
      }
      else if(this.promotivna_cena<=0){
        this.greska_poruka="Promotivna cena mora biti veca od nule.";
        this.uspesno=false;
        this.greska=true;
        return;
      }
      else if(this.knjiga.cena < this.promotivna_cena){
        this.greska_poruka="Promotivna cena mora biti manja od stare cene.";
        this.uspesno=false;
        this.greska=true;
        return;
      }
      else{
        this.knjiga.promocija=true;
        this.knjiga.promotivna_cena=this.promotivna_cena;
        this.uspesno_poruka="Uspešno postavljena promocija za knjigu.";
        this.uspesno=true;
        this.greska=false;
      }
    },
    dodajKnjigu: function(){
      if(this.d_naslov=="" || this.d_autori=="" || this.d_opis=="" || this.d_god=="" || this.d_brstr=="" || this.d_cena==""){
        this.greska_poruka="Morate popuniti sve podatke.";
        this.uspesno=false;
        this.greska=true;
      }
      else if (isNaN(this.d_god)==true || isNaN(this.d_brstr)==true || isNaN(this.d_cena)==true){
        this.greska_poruka="Godina izdanja, broj strana i cena moraju biti broj.";
        this.uspesno=false;
        this.greska=true;
      }
      else if (this.d_slika==""){
        this.greska_poruka="Morate izabrati sliku za knjigu.";
        this.uspesno=false;
        this.greska=true;
      }
      else{
        let knjiga={
        id:this.dohvatiSledeciIDKnjige(),
        naziv:this.d_naslov,
        autori:this.d_autori,
        cena:this.d_cena,
        promocija:false,
        promotivna_cena:0,
        broj_strana:this.d_brstr,
        godina_izdanja:this.d_god,
        opis:this.d_opis,
        slika:this.d_slika
        };
        knjige.push(knjiga);
        this.uspesno_poruka="Uspešno dodata nova knjiga.";
        this.uspesno=true;
        this.greska=false;
      }
    },
    dohvatiSledeciIDKnjige: function(){
      let id=-1;
      for(let k of knjige){
        if(k.id > id) id=k.id;
      }
      return id+1;
    },
    izaberiSliku: function(){
      this.$modal.show("izaberisliku");
    },
    postaviSliku: function(sl){
      this.d_slika=sl;
      this.$modal.hide("izaberisliku");
    }
},
    mounted() {   
    document.title = "Knjižara Perce - Prodavac"; 
    let korime=localStorage.getItem("korisnik");
    if(korime===null) this.$router.push("prijava");
    else{
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      if(korisnik.tip!=1) this.$router.push("kupac");
      this.naziv=korisnik.ime + " " + korisnik.prezime;
      this.naziv+=", prodavac";
      this.predef_slike=predef_slike;
    }
  }
}
</script>

<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>

<div id="navigation">

<div id="naziv">{{naziv}}</div>
 <router-link to="/kupac#" id="odjava" @click.native="odjava">Odjava</router-link>
</div>

<div class="menu">
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;" v-on:click="knjige()">Pregled knjiga <book-icon size="1.7x" class="custom-class"></book-icon></button>
<button type="button" class="btn btn-app" style="margin-top:4px; margin-left:10px;" v-on:click="preporuceneknjige()">Preporučene knjige <bell-icon size="1.5x" class="custom-class"></bell-icon></button>
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px; margin-right:10px;" v-on:click="kupacpromena2()">Promena korisničkog imena/lozinke</button> 
<button type="button" class="btn btn-app" style="margin-top:6px; float:right; margin-left:10px;" v-on:click="kupacpromena1()">Promena podataka</button>
</div>


<div class="row" style="width:100%; position:relative; background-color:#fffee5; margin-left:0px; margin-right:0px;">
  <div class="col-2"><img v-bind:src="'/img/' + knjiga.slika" height="360px" width="230px" style="margin-top:10px; margin-left:10px;"></div>
  <div class="col-10">
    <div style="display:inline-block; font-weight:bold; font-style: italic; font-size:24px;">
    <span style="display:inline-block; font-weight:bold; font-size:24px;">{{knjiga.naziv}}</span>
    <br>
    <span style="display:inline-block; font-weight:bold; font-size:18px;">{{knjiga.autori}}</span>
    <br>
    <span style="display:inline-block; font-weight:bold; font-size:18px;" v-if="knjiga.promocija==false">
      Cena: {{knjiga.cena}} din.
    </span>
    <span style="display:inline-block; font-weight:bold; font-size:18px;" v-if="knjiga.promocija==true">
      Promotivna cena: <span style="text-decoration: line-through;">{{knjiga.cena}}</span>&nbsp; <span style="color:red; font-weight:bold;">{{knjiga.promotivna_cena}}</span> din.
    </span>
    <br>
    <span style="display:inline-block; font-weight:bold; font-size:14px;">
      Broj strana: {{knjiga.broj_strana}} <br>
      Godina izdanja: {{knjiga.godina_izdanja}}.<br><br>
    </span>
    <br>
    <span style="display:inline-block; font-size:15px;">{{knjiga.opis}}</span>
    <button class="btn btn-app" style="position:absolute; top:10px; right: 10px;" v-on:click="preporuciKnjigu()"><span style="font-weight:bold;">Preporuči knjigu</span></button>
    </div>
  </div>
</div>

<div class="row" style="width:100%; position:relative; background-color:#fffee5; margin-left:0px; margin-right:0px;">
<div class="col-5">
<div style="background-color:#FFEF9D; margin-top:20px; margin-left:10px; word-wrap: break-word;" v-for="(kom, index) in komentari" v-bind:key="index">
  <span style="font-weight: bold; margin-left:10px;">Korisnik: {{dohvatiPunoIme(kom.korisnik)}}</span><br>
  <span style="font-weight: bold; margin-left:10px;">Ocena: </span>
  <span v-for="index in kom.ocena" v-bind:key="`${index}11`"><star-icon size="1.0x" class="custom-class" style="fill:#FFC95B;"></star-icon></span>
  <span v-for="index in (5-kom.ocena)" v-bind:key="`${index}12`"><star-icon size="1.0x" class="custom-class" style="fill:white;"></star-icon></span>
  <br>
  <span style="font-weight: bold; margin-left:10px;">Komentar: </span>
  <span style="margin-left:10px;">{{kom.sadrzaj}}</span>
  <br><br>
</div>
</div>


<div class="col-7">
<div class="baner" v-if="postojiKomentar()==false">Dodajte komentar:</div>
<div class="baner" v-if="postojiKomentar()==true">Promenite komentar:</div>

  <div style="background-color:#FFEF9D;">
    <span style="font-weight: bold; margin-left: 10px;">Ocena: </span>
    <span v-for="index in ocena" v-bind:key="`${index}21`"><star-icon size="1.0x" class="custom-class" style="fill:#FFC95B;" v-on:click="promeniOcenu(index)"></star-icon></span>
    <span v-for="index in (5-ocena)" v-bind:key="`${index}22`"><star-icon size="1.0x" class="custom-class" style="fill:white;" v-on:click="promeniOcenu(index+ocena)"></star-icon></span>
    <br>
    <span style="font-weight: bold; margin-left: 10px;">Komentar: </span>
    <br>
    <textarea cols="50" rows="5" style="resize:none; margin-left: 10px;" v-model="sadrzaj"></textarea>
    <br><br>
<button class="btn btn-app" style="margin-left:315px; margin-bottom:20px;" v-on:click="dodajIzmeniKomentar()" v-if="postojiKomentar()==false">Pošalji</button>
<button class="btn btn-app" style="margin-left:315px; margin-bottom:20px;" v-on:click="dodajIzmeniKomentar()" v-if="postojiKomentar()==true">Promeni komentar</button>

<div v-if="uspesno" class="uspesnoProzor">  
  <div class="uspesnoProzorZatvori" v-on:click="uspesno=false"> <x-circle-icon size="1.3x"></x-circle-icon>&nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;
{{uspesno_poruka}}
<br><br>
</div>
<br>
  </div>
</div>
</div>

</div>
</template>


<style scoped>
#naziv{
width:100%; 
margin-top: 50px;
font-size:30px;
}
#odjava{
margin-top: 50px;
margin-right:100px;
font-size:20px;
font-weight: bold;
color: #2c3e50;  
text-decoration: underline; 
text-align:right;
}
td{
  padding: 5px;
}
.greskaProzor{
  text-align: justify;
  background-color: #fa9999;
  height: 10%;
  width: 30%;
  margin-left:30%;
}
.greskaProzorZatvori,.uspesnoProzorZatvori {
  cursor: default;
  font-weight: bold;
  text-align: right;
}
.uspesnoProzor{
  text-align: justify;
  background-color: #0ac438;
  width: 40%;
  margin-left:20%;
}
.baner{
  font-style: oblique;
  font-weight: bold;
  font-size:20px;
  text-decoration: underline;
  text-align: left;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import { BookIcon } from 'vue-feather-icons';
import { BellIcon } from 'vue-feather-icons';
import { XCircleIcon } from 'vue-feather-icons';
import komentari from "../data/komentari.js";
import knjige from "../data/knjige.js";
import { StarIcon } from 'vue-feather-icons';

export default {
  name: "KupacDetaljiKnjige",
  components: {
    BookIcon,
    BellIcon,
    XCircleIcon,
    StarIcon
  },
    data(){
      return{
      naziv:"",
      greska: false,
      greska_poruka: "",
      uspesno: false,
      uspesno_poruka: "",
      knjiga:{
        id:-1,
        naziv:"",
        autori:"",
        cena:0,
        promocija:false,
        promotivna_cena:0,
        broj_strana:0,
        godina_izdanja:0,
        opis:"",
        slika:""
    },
    komentari:[],

    ocena:5,
    sadrzaj:""
    }
  },
  methods:{
    odjava: function(){
      localStorage.clear("korisnik");
      this.$router.push("prijava");
    },
    kupacpromena1: function(){
      this.$router.push('kupac-promena1');
    },
     knjige: function(){
      this.$router.push('kupac');
    },
    kupacpromena2: function(){
      this.$router.push('kupac-promena2');
    },
    preporuciKnjigu: function(){
      this.$router.push('preporuciknjigu');
    },
    dohvatiKomentare:function(){
      this.komentari.splice(0);
      komentari.forEach(kom=>{
        if(kom.knjiga==localStorage.getItem("knjiga_id")) this.komentari.push(kom);
      });
    },
    dohvatiPunoIme: function(korime){
      let korisnik = korisnici.find(k=>k.korime==korime);
      return korisnik.ime + " " + korisnik.prezime + " (" + korime + ")";
     },
    
    promeniOcenu(ocena){
      if(ocena!==undefined && ocena!==null){
        if(ocena>=1 && ocena<=5){
        this.ocena=ocena;
        }
      }
    },
    preporuceneknjige: function(){
      this.$router.push('preporuceneknjige');
    },
    dodajIzmeniKomentar:function(){
      this.dohvatiKomentare();
      let postojeci_komentar = this.komentari.find(kom=>kom.korisnik==localStorage.getItem("korisnik")); 
      if(postojeci_komentar===undefined || postojeci_komentar===null){
        komentari.push({
          knjiga:localStorage.getItem("knjiga_id"),
          korisnik:localStorage.getItem("korisnik"),
          ocena:this.ocena,
          sadrzaj:this.sadrzaj
        });
        this.uspesno_poruka="Uspešno postavljen komentar.";
        this.uspesno=true;
      }
      else{
        postojeci_komentar.sadrzaj=this.sadrzaj;
        postojeci_komentar.ocena=this.ocena;
        this.uspesno_poruka="Uspešno promenjen komentar.";
        this.uspesno=true;
      }
      this.dohvatiKomentare();
    },
    postojiKomentar:function(){
      let postojeci_komentar = this.komentari.find(kom=>kom.korisnik==localStorage.getItem("korisnik")); 
      if(postojeci_komentar===undefined || postojeci_komentar===null) return false;
      else return true;
    }

    },
    mounted() {   
    document.title = "Knjižara Perce - Detalji knjige"; 
    let korime=localStorage.getItem("korisnik");
    if(korime===null) this.$router.push("prijava");
    else{
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      if(korisnik.tip!=0) this.$router.push("prodavac");
      this.naziv=korisnik.ime + " " + korisnik.prezime;
      this.naziv+=", kupac";
      this.knjiga = knjige.find(knjiga => knjiga.id==localStorage.getItem("knjiga_id"));
      if (this.knjiga===undefined || this.knjiga===null) this.$router.push("/kupac");

      this.dohvatiKomentare();
      if(this.postojiKomentar()==false) return;
      else{
        let postojeci_komentar = this.komentari.find(kom=>kom.korisnik==localStorage.getItem("korisnik")); 
        this.ocena = postojeci_komentar.ocena;
        this.sadrzaj = postojeci_komentar.sadrzaj;
      }
    }
  }
}
</script>

<template>
<div>
 <div id="logo">
      <img src="../assets/logo.png" width="100" height="100" id="logo1">
      <div id="logo2">Knjižara Perce</div>
</div>
<div id="navigation">
<router-link to="/prijava" id="prijava">Prijava</router-link> 
 <div id="registracija">Registracija</div>
</div>

<br><br><br><br><br>
  <table class="center">
    <tr>
    <td style="font-size:20px;">Ime:</td>
    <td><input type="text" id="usr" size="25" v-model="ime"></td>
    </tr>

    <tr>
    <td style="font-size:20px;">Prezime:</td>
    <td><input type="text" id="usr" size="25" v-model="prezime"></td>
    </tr>

    <tr>
    <td style="font-size:20px;">Broj telefona:</td>
    <td><input type="text" id="usr" size="25" v-model="brTel"></td>
    </tr>

      <tr>
    <td style="font-size:20px;">Adresa:</td>
    <td><input type="text" id="usr" size="35" v-model="adresa"></td>
    </tr>



    <tr>
    <td style="font-size:20px;">Korisničko ime:</td>
    <td><input type="text" id="usr" size="25" v-model="korime"></td>
    </tr>

    <tr>
      <td style="font-size:20px;"> Lozinka: </td>
      <td> <input type="password" id="pwd" size="25" v-model="lozinka"></td>
    </tr>

    <tr> <td colspan="2" style="text-align: center;"><button type="button" class="btn btn-success" v-on:click="registracija(ime,prezime,brTel,adresa,korime,lozinka)">Pošalji zahtev za registraciju</button></td></tr>
  </table>

<br><br>
<div v-if="greska" class="greskaProzor"> 
  <div class="greskaProzorZatvori" v-on:click="greska=false"> <x-circle-icon size="1.3x"></x-circle-icon> &nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;{{greska_poruka}}
</div>

<div v-if="uspesno" class="uspesnoProzor"> 
  <div class="uspesnoProzorZatvori" v-on:click="uspesno=false"> <x-circle-icon size="1.3x"></x-circle-icon> &nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;{{uspesno_poruka}}
</div>

</div>
</template>

<style scoped>
#prijava{
margin-top: 50px;
margin-left:50px;
color: #2c3e50;
text-decoration: underline;   
}
#registracija{
margin-top: 50px;
margin-left:80px;
font-weight:bold;
color: #2c3e50;
}
td{
  padding: 5px;
}
.greskaProzor{
  text-align: justify;
  background-color: #fa9999;
  height: 10%;
  width: 30%;
  margin-left:30%;
}
.greskaProzorZatvori,.uspesnoProzorZatvori {
  cursor: default;
  font-weight: bold;
  text-align: right;
}
.uspesnoProzor{
  text-align: justify;
  background-color: #0ac438;
  height: 10%;
  width: 40%;
  margin-left:30%;
}
</style>

<script>
import korisnici from "../data/korisnici.js";
import { XCircleIcon } from 'vue-feather-icons';

export default {
  name: 'Registracija',
  components: {
    XCircleIcon
  },
  mounted() {  
    document.title = "Knjižara Perce - Registracija";  
  },
  data(){
    return{
      greska: false,
      greska_poruka: "",
      ime:"",
      prezime:"",
      brTel:"",
      adresa: "",
      korime: "",
      lozinka: "",
      uspesno: false,
      uspesno_poruka: ""
    }
  },
  methods:{
    registracija(ime,prezime,brTel,adresa,korime,lozinka){
      let korisnik = korisnici.find(kor=> kor.korime==korime);
      brTel = brTel.replace(' ','');
      brTel = brTel.replace('-','');

      if(korisnik!==undefined){
      this.greska_poruka="Korisničko ime je zauzeto.";
      this.greska=true;
    }
    else if (isNaN(brTel)){
      this.greska_poruka="Neispravan format broja telefona.";
      this.greska=true;
    }
    else if(ime == "" || prezime== "" || brTel== "" || adresa== "" || korime== "" || lozinka== ""){
      this.greska_poruka="Morate popuniti sve podatke.";
      this.greska=true;
    }
    else{
      let novi_korisnik={
        ime:ime,
        prezime:prezime,
        korime:korime,
        lozinka:lozinka,
        brojTelefona:brTel,
        adresa:adresa,
        tip:0
      };
      korisnici.push(novi_korisnik);
      this.uspesno_poruka="Registracija uspešno obavljena, prebacivanje na stranicu za prijavu...";
      this.greska=false;
      this.uspesno=true;
      setTimeout(() => this.$router.push("prijava"), 3000);
    }
    }
}
}
</script>
